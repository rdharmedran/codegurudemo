package com.macys.cyclecount;

import java.io.IOException;
import java.util.Properties;

import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.vendor.guava.v26_0_jre.com.google.common.collect.ImmutableMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;

public class EpcTestDataLoader extends DoFn<String, PubsubMessage> {

  private static final Logger LOG = LoggerFactory.getLogger(EpcTestDataLoader.class);
  private static final String TEST_DATA_QUERY = "SELECT  EpcHex, EpcUrn, DeptNbr, VndNbr, skuupcnbr, scanTs , userid, invscanhdrid, runid FROM invscanepc where invscanhdrid=101482 order by %1$s limit 50000 ";
  private Spanner spanner = null;
  private DatabaseClient dbClient = null;
  Properties configProperties = null;

  public EpcTestDataLoader() {
    try {
      configProperties = RFIDCycleCountUtil.readPropertiesFile();
    } catch (final IOException e) {
      LOG.error("Error reading configuration file::" + e);
    }
  }

  @StartBundle
  public void startBundle(StartBundleContext c) {
    final com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
        .newBuilder().build();
    spanner = spannerOptions.getService();

    final String spannerProjectID = configProperties.getProperty("gcp.project.id");
    final String spannerInstanceID = configProperties.getProperty("spanner.instance.id");
    final String spannerDatabaseID = configProperties.getProperty("spanner.database.id");
    final DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
    dbClient = spanner.getDatabaseClient(db);
  }

  @FinishBundle
  public void finishBundle(FinishBundleContext c) {
    try {
      dbClient = null;
      spanner.close();
    } catch (final Exception e) {
      LOG.error("error while loading lookup>>>>>>>>>>>>>>>>>>>>>>>>>", e);
    }
  }

  @ProcessElement
  public void processElement(ProcessContext context) {

    final Statement stmtTogetDisplayEpc = Statement
        .newBuilder(String.format(TEST_DATA_QUERY, context.element())).build();
    LOG.info("Test Data Loading >>>>>>>>>>>>>>>>>>>>>>" + stmtTogetDisplayEpc.toString());
    final ResultSet resultSet = dbClient.singleUseReadOnlyTransaction()
        .executeQuery(stmtTogetDisplayEpc);
    while (resultSet.next()) {

      final MyOptions ops = context.getPipelineOptions().as(MyOptions.class);
      final String grpIdList = ops.getHeaderList().get();
      if (grpIdList != null) {
        final Struct testData = resultSet.getCurrentRowAsStruct();
        final String[] grpIdArray = grpIdList.split(",");
        for (final String element : grpIdArray) {
          final String[] invScanGrpHdrId = element.split("_");
          final com.google.cloud.Timestamp scanTs = com.google.cloud.Timestamp
              .parseTimestamp(testData.getTimestamp("scanTs").toString());
          final String jsonString = "{\"INV_SCAN_GRP_ID\":\"" + invScanGrpHdrId[0]
              + "\",\"INV_SCAN_HDR_ID\":\"" + invScanGrpHdrId[1] + "\",\"USER_ID\":\""
              + testData.getString("userid") + "\",\"EPC_HEX\":\"" + testData.getString("EpcHex")
              + "\",\"EPC_URN\":\"" + testData.getString("EpcUrn") + "\",\"SKU_UPC_NBR\":\""
              + testData.getLong("skuupcnbr") + "\",\"SCAN_TS\":\"" + scanTs + "\"}";
          LOG.info(jsonString);
          final PubsubMessage mesg = new PubsubMessage(jsonString.getBytes(),
              ImmutableMap.of("UNIQUE_ID", invScanGrpHdrId[0] + testData.getString("EpcHex")));
          context.output(mesg);

        }
      }
    }
    resultSet.close();
  }

}
