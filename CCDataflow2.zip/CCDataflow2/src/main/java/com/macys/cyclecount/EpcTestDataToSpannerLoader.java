package com.macys.cyclecount;

import java.io.IOException;
import java.util.Properties;

import org.apache.beam.sdk.transforms.DoFn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;

public class EpcTestDataToSpannerLoader extends DoFn<String, Mutation> {

  private static final Logger LOG = LoggerFactory.getLogger(EpcTestDataToSpannerLoader.class);
  private static final String TEST_DATA_QUERY = "SELECT EpcHex, EpcUrn, ps.skuupcnbr, scanTs  FROM EpcTestData dvn join prodsku ps on  (ps.ZlDivnNbr = 71 and ps.skuupcnbr = dvn.skuupcnbr) where dvn.zlStorenbr=%1$s and ( ps.DeptNbr=%2$s and ps.VndNbr=%3$s)";
  private Spanner spanner = null;
  private DatabaseClient dbClient = null;
  Properties configProperties = null;

  public EpcTestDataToSpannerLoader() {
    try {
      configProperties = RFIDCycleCountUtil.readPropertiesFile();
    } catch (final IOException e) {
      LOG.error("Error reading configuration file::" + e);
    }
  }

  @StartBundle
  public void startBundle(StartBundleContext c) {
    final com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
        .newBuilder().build();
    spanner = spannerOptions.getService();

    final String spannerProjectID = configProperties.getProperty("gcp.project.id");
    final String spannerInstanceID = configProperties.getProperty("spanner.instance.id");
    final String spannerDatabaseID = configProperties.getProperty("spanner.database.id");
    final DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
    dbClient = spanner.getDatabaseClient(db);
  }

  @FinishBundle
  public void finishBundle(FinishBundleContext c) {
    try {
      dbClient = null;
      spanner.close();
    } catch (final Exception e) {
      LOG.error("error while loading lookup>>>>>>>>>>>>>>>>>>>>>>>>>", e);
    }
  }

  @ProcessElement
  public void processElement(ProcessContext context) {
    final MyOptions ops = context.getPipelineOptions().as(MyOptions.class);
    final String storeId = ops.getStoreId().get();
    final String[] dv = context.element().split("_");
    final Statement stmtTogetDisplayEpc = Statement
        .newBuilder(String.format(TEST_DATA_QUERY, storeId, dv[0], dv[1])).build();
    LOG.info("Test Data Loading >>>>>>>>>>>>>>>>>>>>>>" + stmtTogetDisplayEpc.toString());
    final String grpId = ops.getSinkGrpId().get();
    final String hdrId = ops.getSinkHeaderId().get();
    final String userId = ops.getUserId().get();
    final ResultSet resultSet = dbClient.singleUseReadOnlyTransaction()
        .executeQuery(stmtTogetDisplayEpc);

    while (resultSet.next()) {

      ops.getHeaderList().get();

      final Struct testData = resultSet.getCurrentRowAsStruct();

      // System.out.println(testData.getLong("count"));
      final com.google.cloud.Timestamp scanTs = com.google.cloud.Timestamp
          .parseTimestamp(testData.getTimestamp("scanTs").toString());
      final Mutation scanDataMutation = Mutation.newInsertOrUpdateBuilder("InvScanEpc")
          .set("InvScanGrpID").to(grpId).set("EpcHex").to(testData.getString("EpcHex"))
          .set("DeptNbr").to(Long.parseLong(dv[0])).set("EpcUrn").to(testData.getString("EpcUrn"))
          .set("InvScanHdrID").to(hdrId).set("RunID").to(0).set("ScanTS").to(scanTs)
          .set("SkuUpcNbr").to(testData.getLong("skuupcnbr")).set("UserID").to(userId).set("VndNbr")
          .to(Long.parseLong(dv[1])).build();

      context.output(scanDataMutation);

    }
    resultSet.close();
  }

}
