package com.macys.cyclecount;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MapFunction extends DoFn<KV<Row, Row>, String> {

  private static final Logger LOG = LoggerFactory.getLogger(MapFunction.class);
  /**
  * 
  */
  private static final long serialVersionUID = 1L;

  @ProcessElement
  public void processElement(ProcessContext c) {

    try {
      final String jsonString = "INV_SCAN_HDR_ID:" + c.element().getKey()
          + ",MESSAGE_TYPE:group-count,SCAN_COUNT:" + c.element().getValue();
      LOG.info("\nWriting to Group Count Pubusb>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>::" + jsonString);
      c.output(jsonString);
    } catch (final Exception e) {
      LOG.error("Init currentValue with zero", e);
    }

  }
}
