



import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.beam.sdk.io.redis.RedisConnectionConfiguration;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;

import redis.clients.jedis.Jedis;



public class GMMDataLoader extends DoFn<Row, KV<String, String>>

{

	private static final String INV_SCAN_GRP_ID = "invScanGrpId";

	private static final String START_SCAN = "start-scan";

	private static final String SCAN_SESSION_ID = "scanSessionId";

	private static final String ACTION_REQUEST = "actionRequest";

	private static final String TARGET_COUNT = "targetCount";

	private static final String GMM_NAME = "gmmName";

	private static final String GROUP_ID = "groupId";

	private static final String GMM_ID = "gmmid";

	private static final Logger LOG = LoggerFactory.getLogger(GMMDataLoader.class);



	private static final String GMM_DATA_QUERY = " select gmmid, gmmName, groupId, sum(targetCount) as targetCount from "

+ " (SELECT mh.gmmid as gmmid, mh.GMMName as gmmName, isg.InvScanGrpID as groupid,Trgt.TargetCount as targetCount, trgt.deptnbr "

+ "FROM InvScanGrp isg Join TargetCntByDVN Trgt on "

+ "(trgt.zldivnnbr = isg.zldivnnbr and trgt.invnbr = isg.invnbr and trgt.countdate = isg.countdate and trgt.zlstorenbr = isg.zlstorenbr and "

+ " trgt.invfiltersw = 1) join mchhier mh on (mh.zldivnnbr = isg.zldivnnbr and mh.deptnbr = trgt.deptnbr and mh.activeind = 1)  where isg.InvScanGrpID=@invScanGrpId "

+ " ) group by gmmid, gmmName, groupid";



	Schema gmmDataLoadSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")

			.addStringField("GMM_ID").addStringField("GMM_NAME").addStringField("TARGET_COUNT").build();




	private Spanner spanner = null;

	private DatabaseClient dbClient = null;

	Properties configProperties = null;

	Jedis client;

	ObjectMapper objectMapper = new ObjectMapper();

	public GMMDataLoader() {

		try {

			configProperties = RFIDCycleCountUtil.readPropertiesFile();

		} catch (final IOException e) {

			LOG.error("GMMDataLoader:Error reading configuration file::" + e);

		}

	}

	@StartBundle

	public void startBundle(StartBundleContext c) {

		final com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions

				.newBuilder().build();

		spanner = spannerOptions.getService();
try {
	objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);


		final String spannerProjectID = configProperties.getProperty("gcp.project.id");

		final String spannerInstanceID = configProperties.getProperty("spanner.instance.id");

		final String spannerDatabaseID = configProperties.getProperty("spanner.database.id");

		final DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);

		dbClient = spanner.getDatabaseClient(db);

		client = RedisConnectionConfiguration.create("127.0.0.1", 6379).connect();
}catch(Exception e) {
	e.printStackTrace();
}
	}



	@FinishBundle

	public void finishBundle(FinishBundleContext c) {

		try {

			dbClient = null;

			spanner.close();

		} catch (final Exception e) {

			LOG.error("GMMDataLoader:error while loading lookup", e);

		}

	}



	@ProcessElement

	public void processElement(ProcessContext c) {

		final Row notificationRow = c.element();

		final String actionRequest = notificationRow.getString(ACTION_REQUEST);

		final long sessionId = notificationRow.getInt64(SCAN_SESSION_ID);

		final long groupId = notificationRow.getInt64(GROUP_ID);
		
		
		try {
		if (actionRequest.equalsIgnoreCase(START_SCAN)) {

			final Statement stmtTogetGMMData = Statement.newBuilder(GMM_DATA_QUERY).bind(INV_SCAN_GRP_ID).to(groupId).build();

			LOG.info("GMM Data Loading ::" + stmtTogetGMMData.toString());

			final ResultSet resultSet = dbClient.singleUseReadOnlyTransaction().executeQuery(stmtTogetGMMData);
			GMMCountDetails details=new GMMCountDetails();
			details.setGroupId(groupId);
			details.setSessionId(sessionId);
			//details.setTotalCount(totalCount);
			details.setZoneName("");
			List<GmmCount> gmmCounts=new ArrayList<>();
			Long totalTargetCount=0l;
			while (resultSet.next()) {

				final Struct struct = resultSet.getCurrentRowAsStruct();

				final String gmmId = String.valueOf(struct.getLong(GMM_ID));


				final String gmmName = String.valueOf(struct.getString(GMM_NAME));

				final String targetCount = String.valueOf(struct.getLong(TARGET_COUNT));
				totalTargetCount+=struct.getLong(TARGET_COUNT);
				GmmCount count=new GmmCount(gmmName, gmmId, struct.getLong(TARGET_COUNT));
				gmmCounts.add(count);
			
				
				//client.set(keyForRedis, valueForRedis);

				c.output(KV.of(groupId+"_"+sessionId+"_"+gmmId, targetCount));

				LOG.info("Key for redis:"+targetCount+"\tValue from Redis::"+targetCount);



			}
			details.setTotalCount(totalTargetCount);
			details.setGmmCounts(gmmCounts);
			client.set(("GMM_"+groupId+"_"+sessionId),objectMapper.writeValueAsString(details));
			resultSet.close();

		}
		} catch (final Exception e) {

			LOG.error("GMMDataLoader:error while loading lookup", e);

		}

	}



}