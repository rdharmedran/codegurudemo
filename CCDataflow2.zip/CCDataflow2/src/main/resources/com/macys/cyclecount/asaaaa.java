package com.macys.cyclecount;

/*

* Licensed to the Apache Software Foundation (ASF) under one

* or more contributor license agreements.  See the NOTICE file

* distributed with this work for additional information

* regarding copyright ownership.  The ASF licenses this file

* to you under the Apache License, Version 2.0 (the

* "License"); you may not use this file except in compliance

* with the License.  You may obtain a copy of the License at

*

*     http://www.apache.org/licenses/LICENSE-2.0

*

* Unless required by applicable law or agreed to in writing, software

* distributed under the License is distributed on an "AS IS" BASIS,

* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

* See the License for the specific language governing permissions and

* limitations under the License.

*/
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.apache.beam.runners.dataflow.DataflowRunner;
import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.KvCoder;
import org.apache.beam.sdk.coders.RowCoder;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.extensions.sql.meta.provider.pubsub.PubsubMessageToRow;
import org.apache.beam.sdk.io.AvroIO;
import org.apache.beam.sdk.io.GenerateSequence;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;

import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.transforms.Distinct;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.JsonToRow;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.windowing.AfterFirst;
import org.apache.beam.sdk.transforms.windowing.AfterPane;
import org.apache.beam.sdk.transforms.windowing.AfterProcessingTime;
import org.apache.beam.sdk.transforms.windowing.AfterWatermark;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.GlobalWindows;
import org.apache.beam.sdk.transforms.windowing.Repeatedly;
import org.apache.beam.sdk.transforms.windowing.Trigger;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.Row;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.joda.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;
import com.google.common.collect.MapMaker;

/**
* 
 * RFID Scanning Dataflow to read data from pubsub and write data
*
*
* 
 * 
 * 
 */
public class RFIDCycleCountStarter7 {
       private static final Logger LOG = LoggerFactory.getLogger(RFIDCycleCountStarter7.class);

       public static void main(String[] args) throws Exception {
    	   final String dvnPopulateQuery="select InvScanGrpId , ps.skuupcnbr, dvn.deptnbr, dvn.vndnbr from InvScanGrp grp join targetCntByDVN dvn on (dvn.ZlDivnNbr = grp.ZlDivnnbr and dvn.ZlStoreNbr = grp.ZlStoreNbr and dvn.CountDate = grp.CountDate) join prodsku ps on (ps.ZlDivnNbr = dvn.ZldivnNbr and ps.DeptNbr = dvn.DeptNbr and ps.VndNbr = dvn.vndnbr  and skuupcnbr in UNNEST( @skuUpcNbr) ) where grp.invscangrpid = @invScanGrpId ";
              Properties configProperties = null;
              try {
                     configProperties = RFIDCycleCountUtil.readPropertiesFile();
              } catch (IOException e) {
                     LOG.error("Error reading configuration file::" + e);
              }
              PipelineOptions options = PipelineOptionsFactory.create();
              
           
              
              
              /*DataflowPipelineOptions options = PipelineOptionsFactory.as(DataflowPipelineOptions.class);
              options.setProject(configProperties.getProperty("gcp.project.id"));
              options.setStagingLocation(configProperties.getProperty("gcp.staging.location"));
              options.setRunner(DataflowRunner.class);
              options.setTemplateLocation(                           configProperties.getProperty("gcp.template.location"));
              options.setRegion(configProperties.getProperty("gcp.region"));
              options.setTempLocation(configProperties.getProperty("gcp.temp.location"));*/
              
              final String SPANNER_PROJECT_ID = configProperties.getProperty("gcp.project.id");
              final String SPANNER_INSTANCE_ID = configProperties.getProperty("spanner.instance.id");
              final String SPANNER_DATABASE_ID = configProperties.getProperty("spanner.database.id");
              Pipeline rfidScanPipeline = Pipeline.create(options);
              LOG.info("Pipeline started");
              Schema rfidScanDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")
                           .addStringField("USER_ID").addStringField("EPC_HEX").addStringField("EPC_URN")
                           .addStringField("SKU_UPC_NBR").addStringField("SCAN_TS").build();
              Schema rfidScanEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
                            .addStringField("INV_SCAN_HDR_ID").addStringField("USER_ID").addStringField("EPC_HEX")
                           .addStringField("EPC_URN").addStringField("DEPT_NBR").addStringField("VND_NBR")
                           .addStringField("SKU_UPC_NBR").addStringField("SCAN_TS").build();
             
              Schema notificationSchema = Schema.builder().addInt64Field("scanSessionId").addStringField("actionRequest")
                           .addStringField("userId").build();
           
              PCollectionView<Map<String, String>> displayEpcMap = rfidScanPipeline
                           .apply(GenerateSequence.from(0).withRate(1, Duration.standardSeconds(3600L)))
                           .apply(Window.<Long>into(new GlobalWindows())
                                         .triggering(Repeatedly.forever(AfterProcessingTime.pastFirstElementInPane()))
                                         .discardingFiredPanes())
                           .apply(ParDo.of(new DoFn<Long, KV<String, String>>() {
                                  private Spanner spanner = null;
                                  private DatabaseClient dbClient = null;

                                  @StartBundle
                                  public void startBundle(StartBundleContext c) {
                                         com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
                                                       .newBuilder().build();
                                         spanner = spannerOptions.getService();
                                         String spannerProjectID = SPANNER_PROJECT_ID;
                                         String spannerInstanceID = SPANNER_INSTANCE_ID;
                                         String spannerDatabaseID = SPANNER_DATABASE_ID;
                                         DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
                                         dbClient = spanner.getDatabaseClient(db);
                                  }

                                  @FinishBundle
                                  public void finishBundle(FinishBundleContext c) {
                                         try {
                                                dbClient = null;
                                                spanner.close();
                                         } catch (Exception e) {
                                                LOG.error(">>>>>>>>>>>>>>>>>>>>>>>>>" + e.getMessage());
                                         }
                                  }

                                  @ProcessElement
                                  public void processElement(ProcessContext c) {
                                         Statement stmtTogetDisplayEpc = Statement.newBuilder(
                                                       "Select tw.ZlDivnNbr,tw.ZlStorenbr,  tw.EpcHex from tagswritten tw  Where tw.ActiveFlag = 'A' and tw.zldivnnbr = 71 and TW.zlstorenbr = 733  and (tw.ZoneName ) in (Select  zn.ZoneName from RfidZone zn Where zn.ZoneType = 'Audit' and tw.ZlDivnNbr =  zn.ZlDivnNbr and zn.ZlStorenbr = tw.ZlStorenbr)  ")
                                                       .build();
                                         LOG.info("Display Tag Statement:::::::::" + stmtTogetDisplayEpc.toString());
                                         ResultSet resultSet = dbClient.singleUseReadOnlyTransaction().executeQuery(stmtTogetDisplayEpc);
//                                              List<Row> displayEpcList = new ArrayList<Row>();
                                         while (resultSet.next()) {
                                                Struct row = resultSet.getCurrentRowAsStruct();
//                                              String divnNbr = String.valueOf(row.getLong(0));
//                                              String storeNbr = String.valueOf(row.getLong(1));
                                                String epcHex = row.getString(2);
//                                              String jsonString = "{\"DIV_NBR\":\"" + divnNbr + "\",\"STORE_NBR\":\"" + storeNbr
//                                                            + "\",\"EPC_HEX\":\"" + epcHex + "\"}";
                                               // Map<String, String> map = new HashMap<>();
                                              //  map.put(epcHex, epcHex);
                                                c.output(KV.of(epcHex, epcHex));
                                         }
                                         resultSet.close();
                                  }
                           })).apply(View.<String, String>asMap());
              ;
              PCollection<PubsubMessage> scanMessage = rfidScanPipeline.apply("ReadPubsub",
                           PubsubIO.readMessagesWithAttributes().withIdAttribute("UNIQUE_ID")
                                         //.fromSubscription("projects/mtech-storesys-np/subscriptions/test-rfid-pull"));
                          .fromSubscription(configProperties.getProperty("device.scan.data.subscription.name")));
              
              
              
              
              /*
               * 
                * ---------------------------------- create micro batches for message with 30
               * 
                * seconds window ends -----------------------------
               * 
                */
               
               PCollection<Row> scanDataRow = scanMessage.apply(ParDo.of(new PubsubMessageToRoW(rfidScanDataSchema,false)
     	                ));

               
             
              /*
              * 
               * ---------------------------------- create micro batches for message with 30
              * 
               * seconds window-----------------------------
              * 
               */
              
          
              PCollection<Row> windowedData = scanDataRow.setCoder(RowCoder.of(rfidScanDataSchema)).apply(Window
                           .<Row>into(FixedWindows.of(Duration.standardSeconds(30)))
                           .triggering(AfterWatermark.pastEndOfWindow()
                                   .withEarlyFirings(
                                           AfterProcessingTime.pastFirstElementInPane()
                                               .plusDelayOf(Duration.standardSeconds(30)))
                                       .withLateFirings(
                                           AfterProcessingTime.pastFirstElementInPane()
                                               .plusDelayOf(Duration.standardSeconds(30))))
                               .withAllowedLateness(Duration.standardSeconds(30))
                           .withAllowedLateness(Duration.standardSeconds(0)).discardingFiredPanes());
                
              
             
           
              /*
              * 
               * ----------------------------------group the message with header id
              * 
               * -----------------------------
              * 
               */
//convert to key value pair
              PCollection<KV<String, Row>> scanDataRow7 = windowedData.setCoder(RowCoder.of(rfidScanDataSchema))
                           .apply("Set EPC Header Id as  key",
                                         MapElements.into(TypeDescriptors.kvs(TypeDescriptors.strings(), TypeDescriptors.rows()))
                                                       .via(row1 -> KV.of(((Row) row1).getString("INV_SCAN_GRP_ID"), row1)))
                           .setRowSchema(rfidScanDataSchema);
              
              
              PCollection<KV<String, Iterable<Row>>> GroupedRecords7 = scanDataRow7
                      .setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(rfidScanDataSchema)))
                      .apply(GroupByKey.<String, Row>create());
              /*
              * 
               * ----------------------------------group the message with header id
              * 
               * ends-----------------------------
              * 
               */
              
              
              
		
              
              
              
              
              
              /*
              * 
               * -------------------------------------- remove display tag from stream using
              * 
               * filter --------------------------------------------
              * 
               */
             
              PCollection<Row> displayremoved = GroupedRecords7.apply("FilterDisplay Tags",
                           ParDo.of(new DoFn<KV<String, Iterable<Row>>, Row>() {
                                  @ProcessElement
                                  public void processElement(ProcessContext c) {
                                         Map<String, String> sideInoput = c.sideInput(displayEpcMap);
                                         Iterable<Row> inputRow = c.element().getValue();
                                         Stream<Row> result = StreamSupport.stream(inputRow.spliterator(), false);
                                         result.filter(entry -> !sideInoput.containsKey(entry.getString("EPC_HEX")))
                                                       .forEach(n -> c.output(n));
                                  }
                           }).withSideInputs(displayEpcMap));
// stream and remove display tag test
              
              PCollection<KV<String, Row>> displayremovedByKV = displayremoved.setCoder(RowCoder.of(rfidScanDataSchema))
                      .apply("Set Group Id as  key",
                                    MapElements.into(TypeDescriptors.kvs(TypeDescriptors.strings(), TypeDescriptors.rows()))
                                                  .via(row1 -> KV.of(((Row) row1).getString("INV_SCAN_HDR_ID"), row1)))
                      .setRowSchema(rfidScanDataSchema);
              
              
              /*
               * 
                * ------------------------- Group the messages by group id
               * 
                * ---------------------------------------------------------
               * 
                */
             
               PCollection<KV<String, Iterable<Row>>> displayremovedByGroupId = displayremovedByKV
                            .setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(rfidScanDataSchema)))
                            .apply(GroupByKey.<String, Row>create());
               
               
              
               PCollection<GroupCount> GroupCountToAvro= displayremovedByGroupId.apply("Update Group Count", ParDo.of(new DoFn<KV<String, Iterable<Row>>, GroupCount>() {
      			@ProcessElement
      			public void processElement(ProcessContext c) {
      				final Iterable<Row> inputRow = c.element().getValue();
      				final long count = StreamSupport.stream(inputRow.spliterator(), false).count();
      				final long key = Long.parseLong(c.element().getKey());
      				GroupCount.Builder itemBuilder =
      						GroupCount.newBuilder();
      				
      				c.output(itemBuilder.setCount(count).setId(key).build());
//      				if (MyData.getInstance().groupCountMap.get(c.element().getKey()) == null) {
//      					MyData.getInstance().groupCountMap.put(c.element().getKey(), count);
//      				} else {
//      					MyData.getInstance().groupCountMap.put(c.element().getKey(), MyData.getInstance().groupCountMap.get(c.element().getKey()) + count);
//
    				//}

      			}
      		}));
                    
               GroupCountToAvro.apply(
            	        "Write to GCS",
            	        new AvroWriter()
            	          .withOutputPath("gs://storesys-rfid-np/Dataflow/perf-opt/staging-per-opt-logs-added/group") 
            	            .withRecordType(GroupCount.class));
           
              /*
              * 
               * ------------------------ populate vendor number and department number by
              * 
               * micro batching based on group id ----------------------------
              * 
               */
              PCollection<Row> deptVndEnriched = displayremovedByGroupId
                           .apply(ParDo.of(new DoFn<KV<String, Iterable<Row>>, Row>() {
                                  private Spanner spanner = null;
                                  private DatabaseClient dbClient = null;

                                  @StartBundle
                                  public void startBundle(StartBundleContext c) {
// TransactionFileOptions options =
// c.getPipelineOptions().as(TransactionFileOptions.class);
                                         com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
                                                       .newBuilder().build();
                                         spanner = spannerOptions.getService();
                                         String spannerProjectID = SPANNER_PROJECT_ID;
                                         String spannerInstanceID = SPANNER_INSTANCE_ID;
                                         String spannerDatabaseID = SPANNER_DATABASE_ID;
                                         DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
                                         dbClient = spanner.getDatabaseClient(db);
                                  }

                                  @FinishBundle
                                  public void finishBundle(FinishBundleContext c) {
                                         try {
                                                dbClient = null;
                                                spanner.close();
                                                LOG.info("*************************Dept Vendor Enriched ************************");
                                         } catch (Exception e) {
                                                LOG.error(">>>>>>>>>>>>>>>>>>>>>>>>>" + e.getMessage());
                                         }
                                  }

                                  @ProcessElement
                                  public void processElement(ProcessContext c) {
                                         KV<String, Iterable<Row>> keyValuepair = c.element();
                                         long invScanGrpId = Long.parseLong(keyValuepair.getKey());
                                         Iterable<Row> inputRow = keyValuepair.getValue();
                                         Stream<Row> result = StreamSupport.stream(inputRow.spliterator(), false);
                                         List<String> skuUpcNbrList = result.map(entry -> entry.getString("SKU_UPC_NBR"))
                                                       .collect(Collectors.toList());
                                         List<Long> longArrayList = skuUpcNbrList.stream().map(Long::parseLong)
                                                       .collect(Collectors.toList());
                                         long skuUpcNbr = 0;
                                         long deptNbr = 0;
                                         long vndNbr = 0;
                                         Map<String, String> materDataMap = new HashMap<>();
                                         Statement stmtToChkDeptVnd = Statement
                                                       .newBuilder(dvnPopulateQuery)
                                                       .bind("invScanGrpId").to(invScanGrpId).bind("skuUpcNbr").toInt64Array(longArrayList)
                                                       .build();
                                         // LOG.info("Statement:::::::::" + stmtToChkDeptVnd.toString());
                                         ResultSet resultSet = dbClient.singleUseReadOnlyTransaction().executeQuery(stmtToChkDeptVnd);
                                         // LOG.info("Statement:::::::::");
                                         while (resultSet.next()) {
                                                Struct row = resultSet.getCurrentRowAsStruct();
                                                // LOG.info("Rows>>>>>>>>>>>>>>>>>>>>>>>>>>:::::::::" + row);
                                                deptNbr = row.getLong("deptnbr");
                                                vndNbr = row.getLong("vndnbr");
                                                skuUpcNbr = row.getLong("skuupcnbr");
// LOG.info("Statement:::::::::" + skuUpcNbr);
                                                materDataMap.put(String.valueOf(skuUpcNbr), (deptNbr + "_" + vndNbr));
                                         }
                                         resultSet.close();
                                         Iterable<Row> inputRow1 = c.element().getValue();
                                         Stream<Row> result1 = StreamSupport.stream(inputRow1.spliterator(), false);
                                         result1.filter(entry -> entry != null)
                                                       .forEach(n -> c.output(n.withSchema(rfidScanEpcDataSchema)
                                                                     .withFieldValue("SCAN_TS", n.getString("SCAN_TS"))
                                                                     .withFieldValue("USER_ID", n.getString("USER_ID"))
                                                                     .withFieldValue("SKU_UPC_NBR", n.getString("SKU_UPC_NBR"))
                                                                     .withFieldValue("EPC_URN", n.getString("EPC_URN"))
                                                                     .withFieldValue("EPC_HEX", n.getString("EPC_HEX"))
                                                                     .withFieldValue("INV_SCAN_HDR_ID", n.getString("INV_SCAN_HDR_ID"))
                                                                     .withFieldValue("INV_SCAN_GRP_ID", n.getString("INV_SCAN_GRP_ID"))
                                                                     .withFieldValue("DEPT_NBR",
                                                                                  materDataMap.get(n.getString("SKU_UPC_NBR")) != null
                                                                                                ? materDataMap.get(n.getString("SKU_UPC_NBR")).split("_")[0]
                                                                                                : "0")
                                                                     .withFieldValue("VND_NBR",
                                                                                  materDataMap.get(n.getString("SKU_UPC_NBR")) != null
                                                                                                ? materDataMap.get(n.getString("SKU_UPC_NBR")).split("_")[1]
                                                                                                : "0")
                                                                     .build()));
                                         materDataMap.clear();
// LOG.info("DeptVendor jsonString : ");
                                  }
                           }));
              
              
              deptVndEnriched.setCoder(RowCoder.of(rfidScanEpcDataSchema))
              .apply("CreateScanDataMutation", ParDo.of(new DoFn<Row, Mutation>() {
                              @ProcessElement
                              public void processElement(ProcessContext c) {
                                              Row inputRow = c.element();
                                              long scnGrpId = Long.parseLong(inputRow.getString("INV_SCAN_GRP_ID"));
                                              long hdrId = Long.parseLong(inputRow.getString("INV_SCAN_HDR_ID"));
                                              long skuUpcNmbr = 0;
                                              try {
                                                              skuUpcNmbr = Long.parseLong(inputRow.getString("SKU_UPC_NBR"));
                                              } catch (Exception e) {
                                                              LOG.error("SKU UPC Number Invalid");
                                              }
                                              com.google.cloud.Timestamp scanTs = com.google.cloud.Timestamp
                                                                              .parseTimestamp(inputRow.getString("SCAN_TS"));
                                              Mutation scanDataMutation = Mutation.newInsertOrUpdateBuilder("InvScanEpc").set("InvScanGrpID")
                                                                              .to(scnGrpId).set("EpcHex").to(inputRow.getString("EPC_HEX")).set("DeptNbr")
                                                                              .to(inputRow.getString("DEPT_NBR")).set("EpcUrn").to(inputRow.getString("EPC_URN"))
                                                                              .set("InvScanHdrID").to(hdrId).set("RunID").to(0).set("ScanTS").to(scanTs)
                                                                              .set("SkuUpcNbr").to(skuUpcNmbr).set("UserID").to(inputRow.getString("USER_ID"))
                                                                              .set("VndNbr").to(inputRow.getString("VND_NBR")).build();
                                              c.output(scanDataMutation);
                              }
              }))
//Finally write the Mutations to Spanner
//scanDataMutations
              .apply("WriteScanData",
                                              SpannerIO.write().withInstanceId(SPANNER_INSTANCE_ID).withDatabaseId(SPANNER_DATABASE_ID))
              .getOutput();
              /*   ------------------------ populate vendor number and department ends                */
              
              /*   ------------------------ write to spanner invscanEpc table starts                */
         
              /*   ------------------------ write to spanner invscanEpc table ends                */  
              
              
              /* department vendor count starts here ..............................*/
      		final Schema rfidScanVendorKeyEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("DEPT_NBR").addStringField("VND_NBR")
      				.build();


      		final PCollection<KV<Row, Row>> rfidScanVendorKeyEpcDataByKV =    deptVndEnriched
      				.apply("Set Group Id as  key",
      						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.rows(), TypeDescriptors.rows()))
      						.via(row1 -> KV.of( Row
      								.withSchema(rfidScanVendorKeyEpcDataSchema).addValues( row1.getString("INV_SCAN_GRP_ID"),row1.getString("DEPT_NBR"), row1.getString("VND_NBR")).build(), row1)));



      		final PCollection<KV<Row, Iterable<Row>>> rfidScanVendorKeyEpcDataaGroupedRecords7 = rfidScanVendorKeyEpcDataByKV
      				.setCoder(KvCoder.of(RowCoder.of(rfidScanVendorKeyEpcDataSchema), RowCoder.of(rfidScanEpcDataSchema)))
      				.apply(GroupByKey.<Row, Row>create());


      		PCollection<DVNCount> dVNCount= rfidScanVendorKeyEpcDataaGroupedRecords7.apply(ParDo.of(new DoFn<KV<Row, Iterable<Row>>, DVNCount>() {
      			@ProcessElement
      			public void processElement(ProcessContext c) {

      				final KV<Row, Iterable<Row>> message = c.element();
      				final long count = StreamSupport.stream(message.getValue().spliterator(), false).count();
      				final String key =message.getKey().getString("INV_SCAN_GRP_ID")+"_"+ message.getKey().getString("DEPT_NBR")+"_"+message.getKey().getString("VND_NBR");
      				//MyData.getInstance().dvnMap.put(key, MyData.getInstance().dvnMap.get(key)!=null?(count+MyData.getInstance().dvnMap.get(key)):count);
      				//System.out.println(key+"dvn"+count+MyData.getInstance().dvnMap.get(key));
      				DVNCount.Builder itemBuilder =
      						DVNCount.newBuilder();
       				
      				c.output(itemBuilder.setCount(count).setId(key).build());
      				//c.output(data);
      			}
      		}));
      		
      		
      		
                 
      		dVNCount.apply(
         	        "Write to GCS",
         	        new AvroWriter()
         	       .withOutputPath("gs://storesys-rfid-np/Dataflow/perf-opt/staging-per-opt-logs-added/dvn") 
         	            .withRecordType(DVNCount.class));
      		
      		
      		
      		
      		
      		
      		
      		
      		
      		
      		
      		/* department vendor count ends here ..............................*/    
              
              
      		/* sku count starts here ..............................*/
    		final Schema rfidScanVendorSKUCountSchema = Schema.builder().addStringField("DEPT_NBR").addStringField("VND_NBR").addStringField("SKU_UPC_NBR").addStringField("INV_SCAN_GRP_ID").addInt64Field("TIME_STAMP")
    				.build();


    		final PCollection<KV<Row, Row>> rfidScanVendorSKUEpcDataByKV = deptVndEnriched
    				.apply("Set Group Id as  key",
    						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.rows(), TypeDescriptors.rows()))
    						.via(row1 -> KV.of( Row
    								.withSchema(rfidScanVendorSKUCountSchema).addValues( row1.getString("DEPT_NBR"), row1.getString("VND_NBR"),row1.getString("SKU_UPC_NBR"),row1.getString("INV_SCAN_GRP_ID"),new Long(System.currentTimeMillis())).build(), row1)));



    		final PCollection<KV<Row, Iterable<Row>>> rfidScanVendorSKUDataaGroupedRecords7 = rfidScanVendorSKUEpcDataByKV
    				.setCoder(KvCoder.of(RowCoder.of(rfidScanVendorSKUCountSchema), RowCoder.of(rfidScanEpcDataSchema)))
    				.apply(GroupByKey.<Row, Row>create());


    		PCollection<SKUCount> sKUCount= rfidScanVendorSKUDataaGroupedRecords7.apply(ParDo.of(new DoFn<KV<Row, Iterable<Row>>, SKUCount>() {
    			
    			@ProcessElement
    			public void processElement(ProcessContext c) {

    				final KV<Row, Iterable<Row>> message = c.element();
    				final long count = StreamSupport.stream(message.getValue().spliterator(), false).count();
    				final String key = message.getKey().getString("INV_SCAN_GRP_ID")+"_"+message.getKey().getString("DEPT_NBR")+"_"+message.getKey().getString("VND_NBR")+"_"+message.getKey().getString("SKU_UPC_NBR")+"_"+message.getKey().getInt64("TIME_STAMP");
    				//System.out.println(key+"MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMm"+count);
    				SKUCount.Builder itemBuilder =
    						SKUCount.newBuilder();
       				
      				c.output(itemBuilder.setCount(count).setId(key).build());

    				//c.output(data);
    			}
    		}));

    		sKUCount.apply(
         	        "Write to GCS",
         	        new AvroWriter()
         	       .withOutputPath("gs://storesys-rfid-np/Dataflow/perf-opt/staging-per-opt-logs-added/sku") 
         	            .withRecordType(SKUCount.class));
             
              
    	    PCollection<GroupCount> groupCountCollection = rfidScanPipeline
                    
                    .apply("TakeGroupCount", AvroIO.read(GroupCount.class).from("gs://storesys-rfid-np/Dataflow/perf-opt/staging-per-opt-logs-added*.avro")) ;
       groupCountCollection.apply(Window.<GroupCount>into(FixedWindows.of(Duration.standardSeconds(60)))
                            .triggering(AfterWatermark.pastEndOfWindow()
                                    .withEarlyFirings(
                                            AfterProcessingTime.pastFirstElementInPane()
                                                .plusDelayOf(Duration.standardSeconds(30)))
                                        .withLateFirings(
                                            AfterProcessingTime.pastFirstElementInPane()
                                                .plusDelayOf(Duration.standardSeconds(30))))
                                .withAllowedLateness(Duration.standardSeconds(30))
                            .withAllowedLateness(Duration.standardSeconds(0)).discardingFiredPanes()).apply("WriteCountToPubsub",
                                  PubsubIO.writeAvros(GroupCount.class).to(configProperties.getProperty("group.count.topic.name")));
              
             /* groupCountCollection.apply(ParDo.of(new DoFn<String, Mutation>() {
			@ProcessElement
			public void processElement(ProcessContext c) {
				String jsonStr = c.element();
				if (null != jsonStr) {
					String[] splittedVal = jsonStr.split(",");
					String[] invScanHdrIdStr = splittedVal[0].split(":");
					String[] groupCountStr = splittedVal[2].split(":");
					System.out.println(invScanHdrIdStr[1]+">>>>>>>>>>>>groupCountStr[1]>>>>>>>>>>>>>>>>>>>>>>>>>>>."+groupCountStr[1]);
					Mutation groupCountMutation = Mutation.newUpdateBuilder("InvScanHdr").set("InvScanHdrID")
							.to(new Long(invScanHdrIdStr[1]).longValue()).set("ScanCount")
							.to(new Long(groupCountStr[1]).longValue()).set("LastUpdTS")
							.to(com.google.cloud.Timestamp.now()).set("LastUpdUser").to("CycleCountDataFlow").build();
					c.output(groupCountMutation);
				}
			}
		})).apply("WriteGroupCountToHeader",
				SpannerIO.write().withProjectId(SPANNER_PROJECT_ID).withInstanceId(SPANNER_INSTANCE_ID).withDatabaseId(SPANNER_DATABASE_ID));
            */  

              /*
              * 
               * ------------------------Insertion into InvScanCntByDVN /InvScanCntBySku
              * 
               * ----------------------------
              * 
               */
              
    		PCollection<DVNCount> dVNCountCollection=  rfidScanPipeline
              
              .apply("Update SKU Count", AvroIO.read(DVNCount.class).from("gs://storesys-rfid-np/Dataflow/perf-opt/staging-per-opt-logs-added/dvn*.avro")) ;
    		dVNCountCollection.apply(Window.<DVNCount>into(FixedWindows.of(Duration.standardSeconds(60)))
                      .triggering(AfterWatermark.pastEndOfWindow()
                              .withEarlyFirings(
                                      AfterProcessingTime.pastFirstElementInPane()
                                          .plusDelayOf(Duration.standardSeconds(30)))
                                  .withLateFirings(
                                      AfterProcessingTime.pastFirstElementInPane()
                                          .plusDelayOf(Duration.standardSeconds(30))))
                          .withAllowedLateness(Duration.standardSeconds(30))
                      .withAllowedLateness(Duration.standardSeconds(0)).discardingFiredPanes())
                           .apply("Insertion into InvScanCntByDVN /InvScanCntBySku", ParDo.of(new DoFn<DVNCount, Mutation>() {
                              

                                  @ProcessElement
                                  public void processElement(ProcessContext c) {
                                         LOG.info("cntbysku & ByDVN update in progress.. ");

                                       
                                         	System.out.println("keykeykeykeykeykeykeykeykeykeykeykey");

                                                                                  String key = c.element().id;                                                                         	System.out.println(key+"keykeykeykeykeykeykeykeykeykeykeykey");

                                                                                  String[] keys=key.split("_");
                                                                                  
                                                                                  
                                                                                  Mutation cntBySkuMutation = Mutation.newInsertOrUpdateBuilder("InvScanCntbySKU")
                                                                                          .set("InvScanGrpID").to(Long.parseLong(keys[3])).set("skuupcnbr")
                                                                                          .to(Long.parseLong(keys[2])).set("DeptNbr")
                                                                                          .to(Long.parseLong(keys[0])).set("VndNbr").to(Long.parseLong(keys[1])).set("ScanCount").to(MyData.getInstance().dvnMap.get(key)).build();
                                                                              	System.out.println(key+"ssssssssssssssssssssssssssssss"+MyData.getInstance().dvnMap.get(key));
                                                                                  
                                                                                  	c.output(cntBySkuMutation);
                                                                           }
                                        
                                 
                           })).apply("WriteScanData",
                                         SpannerIO.write().withProjectId(SPANNER_PROJECT_ID).withInstanceId(SPANNER_INSTANCE_ID).withDatabaseId(SPANNER_DATABASE_ID));
    		
    		
    		PCollection<SKUCount> sKUCountCollection=  rfidScanPipeline
    	              
    	              .apply("Update DVN Count", AvroIO.read(SKUCount.class).from("gs://storesys-rfid-np/Dataflow/perf-opt/staging-per-opt-logs-added/sku*.avro")) ;
    		sKUCountCollection.apply(Window.<SKUCount>into(FixedWindows.of(Duration.standardSeconds(60)))
    	                      .triggering(AfterWatermark.pastEndOfWindow()
    	                              .withEarlyFirings(
    	                                      AfterProcessingTime.pastFirstElementInPane()
    	                                          .plusDelayOf(Duration.standardSeconds(30)))
    	                                  .withLateFirings(
    	                                      AfterProcessingTime.pastFirstElementInPane()
    	                                          .plusDelayOf(Duration.standardSeconds(30))))
    	                          .withAllowedLateness(Duration.standardSeconds(30))
    	                      .withAllowedLateness(Duration.standardSeconds(0)).discardingFiredPanes())
    	                           .apply("Insertion into InvScanCntByDVN /InvScanCntBySku", ParDo.of(new DoFn<SKUCount, Mutation>() {
    	                              

    	                                  @ProcessElement
    	                                  public void processElement(ProcessContext c) {
    	                                         LOG.info("cntbysku & ByDVN update in progress.. ");

    	                                       
    	                                         	System.out.println("keykeykeykeykeykeykeykeykeykeykeykey");

    	                                                                                  String key = c.element().id;                                                                         	System.out.println(key+"keykeykeykeykeykeykeykeykeykeykeykey");

    	                                                                                  String[] keys=key.split("_");
    	                                                                                  
    	                                                                                  
    	                                                                                  Mutation cntBySkuMutation = Mutation.newInsertOrUpdateBuilder("InvScanCntbyDVN")
    	                                                                                          .set("InvScanGrpID").to(Long.parseLong(keys[0])).set("DeptNbr")
    	                                                                                          .to(Long.parseLong(keys[1])).set("VndNbr").to(Long.parseLong(keys[2])).set("ScanCount").to(MyData.getInstance().dvnMap.get(key)).build();
    	                                                                              	System.out.println(key+"ssssssssssssssssssssssssssssss"+MyData.getInstance().dvnMap.get(key));
    	                                                                                  
    	                                                                                  	c.output(cntBySkuMutation);
    	                                                                           }
    	                                        
    	                                 
    	                           })).apply("WriteScanData",
    	                                         SpannerIO.write().withProjectId(SPANNER_PROJECT_ID).withInstanceId(SPANNER_INSTANCE_ID).withDatabaseId(SPANNER_DATABASE_ID));
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
              rfidScanPipeline
                           .apply("ReadNotificationPubsub", PubsubIO.readStrings().fromSubscription(
                                         "projects/mtech-storesys-np/subscriptions/cycle-count-submit-notification-rfid-np-dev-pull"))
                           .apply("JSONToRow", JsonToRow.withSchema(notificationSchema)).apply(ParDo.of(new DoFn<Row, String>() {
                                  private Spanner spanner = null;
                                  private DatabaseClient dbClient = null;

                                  @StartBundle
                                  public void startBundle(StartBundleContext c) {
// TransactionFileOptions options =
// c.getPipelineOptions().as(TransactionFileOptions.class);
                                         com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
                                                       .newBuilder().build();
                                         spanner = spannerOptions.getService();
                                         String spannerProjectID = SPANNER_PROJECT_ID;
                                         String spannerInstanceID = SPANNER_INSTANCE_ID;
                                         String spannerDatabaseID = SPANNER_DATABASE_ID;
                                         DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
                                         dbClient = spanner.getDatabaseClient(db);
                                  }

                                  @FinishBundle
                                  public void finishBundle(FinishBundleContext c) {
                                         dbClient = null;
                                         spanner.close();
                                  }

                                  @ProcessElement
                                  public void processElement(ProcessContext c) {
                                         LOG.info("\nData from notification pubsub:::::::::" + c.element().toString());
                                         Row inputRow = c.element();
                                         String actionRequest = inputRow.getString("actionRequest");
                                         long InvScanHdrID = inputRow.getInt64("scanSessionId");
                                         String userId = inputRow.getString("userId");
                                         if (actionRequest.equalsIgnoreCase("done")) {
                                                long actualCount = 0;
                                                long totalCount = 0;
                                                Statement stmntForActualCount = Statement.newBuilder(
                                                              "select InvScanHdrID,count(*) as actualCount from InvScanEpc where InvScanHdrID = @inscanHeaderId and DeptNbr!=0 and VndNbr!=0  group by InvScanHdrID")
                                                              .bind("inscanHeaderId").to(InvScanHdrID).build();
                                                ResultSet resultSet = dbClient.singleUseReadOnlyTransaction()
                                                              .executeQuery(stmntForActualCount);
                                                if (resultSet.next()) {
                                                       Struct row = resultSet.getCurrentRowAsStruct();
                                                       actualCount = row.getLong("actualCount");
// LOG.info("Data::" + row.getLong("actualCount") + "::" + row.getLong("InvScanHdrID"));
                                                }
                                                resultSet.close();
                                                Statement stmntForTotalCount = Statement.newBuilder(
                                                              "select InvScanHdrID,count(*) as totalCount from InvScanEpc where InvScanHdrID = @inscanHeaderId group by InvScanHdrID")
                                                              .bind("inscanHeaderId").to(InvScanHdrID).build();
                                                ResultSet resultSetTotalCount = dbClient.singleUseReadOnlyTransaction()
                                                              .executeQuery(stmntForTotalCount);
                                                if (resultSetTotalCount.next()) {
                                                       Struct row = resultSetTotalCount.getCurrentRowAsStruct();
                                                       totalCount = row.getLong("totalCount");
                                  // LOG.info("TotalCount::" + row.getLong("totalCount") + "::"
                                  // + row.getLong("InvScanHdrID"));
                                                }
                                                resultSetTotalCount.close();
                                                String scanSummary = "INV_SCAN_HDR_ID:" + InvScanHdrID
                                                              + ",MESSAGE_TYPE:scan-summary,SCAN_COUNT:" + totalCount + ",USER_ID:" + userId
                                                              + ",EXPECTED_ITEMS_COUNT:" + actualCount;
                                                LOG.info("Publishing scan summary::" + scanSummary.toString());
                                                c.output(scanSummary);
                                         }
                                  }
                           })).apply("WriteScanSummaryToPubsub",
                                         PubsubIO.writeStrings().to(configProperties.getProperty("group.count.topic.name")));
              rfidScanPipeline.run().waitUntilFinish();
       }
}

