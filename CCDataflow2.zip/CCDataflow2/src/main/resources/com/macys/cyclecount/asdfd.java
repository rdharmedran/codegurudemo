package com.macys.cyclecount;

package com.macys.rfid.cyclecount.dataflow;

/*

* Licensed to the Apache Software Foundation (ASF) under one

* or more contributor license agreements.  See the NOTICE file

* distributed with this work for additional information

* regarding copyright ownership.  The ASF licenses this file

* to you under the Apache License, Version 2.0 (the

* "License"); you may not use this file except in compliance

* with the License.  You may obtain a copy of the License at

*

*     http://www.apache.org/licenses/LICENSE-2.0

*

* Unless required by applicable law or agreed to in writing, software

* distributed under the License is distributed on an "AS IS" BASIS,

* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

* See the License for the specific language governing permissions and

* limitations under the License.

*/
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.apache.beam.runners.dataflow.DataflowRunner;
import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.KvCoder;
import org.apache.beam.sdk.coders.RowCoder;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.GenerateSequence;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.transforms.Distinct;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.JsonToRow;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.windowing.AfterProcessingTime;
import org.apache.beam.sdk.transforms.windowing.AfterWatermark;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.GlobalWindows;
import org.apache.beam.sdk.transforms.windowing.Repeatedly;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.Row;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.joda.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;

/**
* 
 * RFID Scanning Dataflow to read data from pubsub and write data
*
*
* 
 * 
 * 
 */
public class RFIDCycleCountStarter {
                private static final Logger LOG = LoggerFactory.getLogger(RFIDCycleCountStarter.class);

                public static void main(String[] args) throws Exception {
                                Properties configProperties = null;
                                try {
                                                configProperties = RFIDCycleCountUtil.readPropertiesFile();
                                } catch (IOException e) {
                                                LOG.error("Error reading configuration file::" + e);
                                }
                                //PipelineOptions options = PipelineOptionsFactory.create();
                                
                                DataflowPipelineOptions options = PipelineOptionsFactory.as(DataflowPipelineOptions.class);
                                options.setProject(configProperties.getProperty("gcp.project.id"));
                                options.setStagingLocation(configProperties.getProperty("gcp.staging.location"));
                                options.setRunner(DataflowRunner.class);
                                options.setTemplateLocation(
                                                                configProperties.getProperty("gcp.template.location"));
                                options.setRegion(configProperties.getProperty("gcp.region"));
                                options.setTempLocation(configProperties.getProperty("gcp.temp.location"));
                                
                                final String SPANNER_PROJECT_ID = configProperties.getProperty("gcp.project.id");
                                final String SPANNER_INSTANCE_ID = configProperties.getProperty("spanner.instance.id");
                                final String SPANNER_DATABASE_ID = configProperties.getProperty("spanner.database.id");
                                
                                Pipeline rfidScanPipeline = Pipeline.create(options);
                                LOG.info("Pipeline started");
                                
                                Schema rfidScanDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")
                                                                .addStringField("USER_ID").addStringField("EPC_HEX").addStringField("EPC_URN")
                                                                .addStringField("SKU_UPC_NBR").addStringField("SCAN_TS").build();
                                Schema rfidScanEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
                                                                .addStringField("INV_SCAN_HDR_ID").addStringField("USER_ID").addStringField("EPC_HEX")
                                                                .addStringField("EPC_URN").addStringField("DEPT_NBR").addStringField("VND_NBR")
                                                                .addStringField("SKU_UPC_NBR").addStringField("SCAN_TS").build();
                                Schema rfidScanCountSchema = Schema.builder().addStringField("INV_SCAN_HDR_ID").addInt64Field("GROUP_COUNT")
                                                                .build();
                                Schema targetCntByDVNSchema = Schema.builder().addStringField("DIV_NBR").addStringField("COUNT_DATE")
                                                                .addStringField("STORE_NBR").addStringField("DEPT_NBR").addStringField("VND_NBR").build();
                                Schema invScanGrpSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("DIV_NBR")
                                                                .addStringField("COUNT_DATE").addStringField("STORE_NBR").build();
                                Schema prodSkuSchema = Schema.builder().addStringField("DIV_NBR").addStringField("SKU_UPC")
                                                                .addStringField("DEPT_NBR").addStringField("VND_NBR").build();
                                Schema rfidDisplayEpcHexSchema = Schema.builder().addStringField("DIV_NBR").addStringField("STORE_NBR")
                                                                .addStringField("ZONE_NAME").addStringField("EPC_HEX").build();
                                Schema rfidZoneSchema = Schema.builder().addStringField("DIV_NBR").addStringField("STORE_NBR")
                                                                .addStringField("ZONE_NAME").build();
                                Schema displayEpcSchema = Schema.builder().addStringField("EPC_HEX").build();
                                Schema rfidDisplayRemovedEpcHexSchema = Schema.builder().addStringField("INV_SCAN_HDR_ID")
                                                                .addStringField("EPC_HEX").addStringField("EPC_URN")
//              .addStringField("DISPLAY_EPC")
                                                                .build();
                                Schema notificationSchema = Schema.builder().addInt64Field("scanSessionId").addStringField("actionRequest")
                                                                .addStringField("userId").build();
                                Schema rfidRunIdSchema = Schema.builder().addStringField("SEQ_NAME").addInt64Field("BEG_SEQ_VAL")
                                                                .addInt64Field("RUN_ID").addInt64Field("INCRIMENT_BY").addInt64Field("MAX_SEQ_VAL")
                                                                .addStringField("SEQ_DESC").build();
                                PCollectionView<Map<String, String>> displayEpcMap = rfidScanPipeline
                                                                .apply(GenerateSequence.from(0).withRate(1, Duration.standardSeconds(3600L)))
                                                                .apply(Window.<Long>into(new GlobalWindows())
                                                                                                .triggering(Repeatedly.forever(AfterProcessingTime.pastFirstElementInPane()))
                                                                                                .discardingFiredPanes())
                                                                .apply(ParDo.of(new DoFn<Long, KV<String, String>>() {
                                                                                private Spanner spanner = null;
                                                                                private DatabaseClient dbClient = null;

                                                                                @StartBundle
                                                                                public void startBundle(StartBundleContext c) {
                                                                                                com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
                                                                                                                                .newBuilder().build();
                                                                                                spanner = spannerOptions.getService();
                                                                                                String spannerProjectID = SPANNER_PROJECT_ID;
                                                                                                String spannerInstanceID = SPANNER_INSTANCE_ID;
                                                                                                String spannerDatabaseID = SPANNER_DATABASE_ID;
                                                                                                DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
                                                                                                dbClient = spanner.getDatabaseClient(db);
                                                                                }

                                                                                @FinishBundle
                                                                                public void finishBundle(FinishBundleContext c) {
                                                                                                try {
                                                                                                                dbClient = null;
                                                                                                                spanner.close();
                                                                                                } catch (Exception e) {
                                                                                                                LOG.error(">>>>>>>>>>>>>>>>>>>>>>>>>" + e.getMessage());
                                                                                                }
                                                                                }

                                                                                @ProcessElement
                                                                                public void processElement(ProcessContext c) {
                                                                                                Statement stmtTogetDisplayEpc = Statement.newBuilder(
                                                                                                                                "Select tw.ZlDivnNbr,tw.ZlStorenbr,  tw.EpcHex from tagswritten tw  Where tw.ActiveFlag = 'A' and tw.zldivnnbr = 71 and (tw.ZoneName ) in (Select  zn.ZoneName from RfidZone zn Where zn.ZoneType = 'Audit' and tw.ZlDivnNbr =  zn.ZlDivnNbr and zn.ZlStorenbr = tw.ZlStorenbr)  ")
                                                                                                                                .build();
                                                                                                LOG.info("Display Tag Statement:::::::::" + stmtTogetDisplayEpc.toString());
                                                                                                ResultSet resultSet = dbClient.singleUseReadOnlyTransaction().executeQuery(stmtTogetDisplayEpc);
//                                              List<Row> displayEpcList = new ArrayList<Row>();
                                                                                                while (resultSet.next()) {
                                                                                                                Struct row = resultSet.getCurrentRowAsStruct();
//                                              String divnNbr = String.valueOf(row.getLong(0));
//                                              String storeNbr = String.valueOf(row.getLong(1));
                                                                                                                String epcHex = row.getString(2);
//                                              String jsonString = "{\"DIV_NBR\":\"" + divnNbr + "\",\"STORE_NBR\":\"" + storeNbr
//                                                            + "\",\"EPC_HEX\":\"" + epcHex + "\"}";
                                                                                                                Map<String, String> map = new HashMap<>();
                                                                                                                map.put(epcHex, epcHex);
                                                                                                                c.output(KV.of(epcHex, epcHex));
                                                                                                }
                                                                                                resultSet.close();
                                                                                }
                                                                })).apply(View.<String, String>asMap());
                                ;
                                PCollection<PubsubMessage> scanMessage = rfidScanPipeline.apply("ReadPubsub",
                                                                PubsubIO.readMessagesWithAttributes().withIdAttribute("UNIQUE_ID")
                                                                                                //.fromSubscription("projects/mtech-storesys-np/subscriptions/test-rfid-pull"));
                          .fromSubscription(configProperties.getProperty("device.scan.data.subscription.name")));
                                /*
                                * 
                                 * ---------------------------------- group data test login for incoming message
                                * 
                                 * -----------------------------
                                * 
                                 */
                                PCollection<String> scanData = scanMessage.apply(ParDo.of(new DoFn<PubsubMessage, String>() {
                                                @ProcessElement
                                                public void processElement(ProcessContext c) {
                                                                PubsubMessage message = c.element();
                                                                String epcHex = message.getAttribute("UNIQUE_ID");
                                                                String data = new String(message.getPayload(), StandardCharsets.UTF_8);
                                                                LOG.info(" Attribute:: " + epcHex);
                                                                c.output(data);
                                                }
                                }));
                                /*
                                * 
                                 * ---------------------------------- group data test login for incoming message
                                * 
                                 * ends -----------------------------
                                * 
                                 */
                                /*
                                * 
                                 * ---------------------------------- create micro batches for message with 30
                                * 
                                 * seconds window-----------------------------
                                * 
                                 */
                                PCollection<String> windowedData = scanData.apply(Window
                                                                .<String>into(FixedWindows.of(Duration.standardSeconds(30)))
                                                                .triggering(AfterWatermark.pastEndOfWindow()
                                                                                                .withEarlyFirings(
                                                                                                                                AfterProcessingTime.pastFirstElementInPane().plusDelayOf(Duration.standardSeconds(30)))
                                                                                                .withLateFirings(
                                                                                                                                AfterProcessingTime.pastFirstElementInPane().plusDelayOf(Duration.standardSeconds(30))))
                                                                .withAllowedLateness(Duration.standardSeconds(5)).discardingFiredPanes());
                                /*
                                * 
                                 * ---------------------------------- create micro batches for message with 30
                                * 
                                 * seconds window ends -----------------------------
                                * 
                                 */
                                /*
                                * 
                                 * ---------------------------------- Convert String message to Row
                                * 
                                 * -----------------------------
                                * 
                                 */
                                PCollection<Row> scanDataRow = windowedData.apply("JSONToRow", JsonToRow.withSchema(rfidScanDataSchema));
                                /*
                                * 
                                 * ---------------------------------- Convert String message to Row end
                                * 
                                 * -----------------------------
                                * 
                                 */
                                /*
                                * 
                                 * ----------------------------------group the message with header id
                                * 
                                 * -----------------------------
                                * 
                                 */
//convert to key value pair
                                PCollection<KV<String, Row>> scanDataRow7 = scanDataRow
                                                                .apply("Set EPC Header Id as  key",
                                                                                                MapElements.into(TypeDescriptors.kvs(TypeDescriptors.strings(), TypeDescriptors.rows()))
                                                                                                                                .via(row1 -> KV.of(((Row) row1).getString("INV_SCAN_HDR_ID"), row1)))
                                                                .setRowSchema(rfidScanDataSchema);
                                /*
                                * 
                                 * ----------------------------------group the message with header id
                                * 
                                 * ends-----------------------------
                                * 
                                 */
                                /*
                                * 
                                 * -------------------------------------- remove display tag from stream using
                                * 
                                 * filter --------------------------------------------
                                * 
                                 */
                                PCollection<KV<String, Iterable<Row>>> GroupedRecords7 = scanDataRow7
                                                                .setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(rfidScanDataSchema)))
                                                                .apply(GroupByKey.<String, Row>create());
                                PCollection<Row> displayremoved = GroupedRecords7.apply("FilterDisplay Tags",
                                                                ParDo.of(new DoFn<KV<String, Iterable<Row>>, Row>() {
                                                                                @ProcessElement
                                                                                public void processElement(ProcessContext c) {
                                                                                                Map<String, String> sideInoput = c.sideInput(displayEpcMap);
                                                                                                Iterable<Row> inputRow = c.element().getValue();
                                                                                                Stream<Row> result = StreamSupport.stream(inputRow.spliterator(), false);
                                                                                                result.filter(entry -> !sideInoput.containsKey(entry.getString("EPC_HEX")))
                                                                                                                                .forEach(n -> c.output(n));
                                                                                }
                                                                }).withSideInputs(displayEpcMap));
// stream and remove display tag test
                                /*
                                * displayremoved.setCoder(RowCoder.of(rfidScanDataSchema)).
                                * apply("FilterDisplay Tags", ParDo.of(new DoFn<Row, String>() {
                                * 
                                 * @ProcessElement public void processElement(ProcessContext c) { Row inputRow =
                                * c.element(); LOG.
                                * info("NonDisplay Tagsjs<>><<><>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<onString ::"
                                * + inputRow.getString("EPC_HEX")); } }));
                                */
                                /*
                                * 
                                 * ------------------------- Group the messages by group id
                                * 
                                 * ---------------------------------------------------------
                                * 
                                 */
                                PCollection<KV<String, Row>> displayremovedByKV = displayremoved.setCoder(RowCoder.of(rfidScanDataSchema))
                                                                .apply("Set Group Id as  key",
                                                                                                MapElements.into(TypeDescriptors.kvs(TypeDescriptors.strings(), TypeDescriptors.rows()))
                                                                                                                                .via(row1 -> KV.of(((Row) row1).getString("INV_SCAN_GRP_ID"), row1)))
                                                                .setRowSchema(rfidScanDataSchema);
                                PCollection<KV<String, Iterable<Row>>> displayremovedByGroupId = displayremovedByKV
                                                                .setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(rfidScanDataSchema)))
                                                                .apply(GroupByKey.<String, Row>create());
                                /*
                                * 
                                 * ------------------------ populate vendor number and department number by
                                * 
                                 * micro batching based on group id ----------------------------
                                * 
                                 */
                                PCollection<Row> deptVndEnriched = displayremovedByGroupId
                                                                .apply(ParDo.of(new DoFn<KV<String, Iterable<Row>>, Row>() {
                                                                                private Spanner spanner = null;
                                                                                private DatabaseClient dbClient = null;

                                                                                @StartBundle
                                                                                public void startBundle(StartBundleContext c) {
// TransactionFileOptions options =
// c.getPipelineOptions().as(TransactionFileOptions.class);
                                                                                                com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
                                                                                                                                .newBuilder().build();
                                                                                                spanner = spannerOptions.getService();
                                                                                                String spannerProjectID = SPANNER_PROJECT_ID;
                                                                                                String spannerInstanceID = SPANNER_INSTANCE_ID;
                                                                                                String spannerDatabaseID = SPANNER_DATABASE_ID;
                                                                                                DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
                                                                                                dbClient = spanner.getDatabaseClient(db);
                                                                                }

                                                                                @FinishBundle
                                                                                public void finishBundle(FinishBundleContext c) {
                                                                                                try {
                                                                                                                dbClient = null;
                                                                                                                spanner.close();
                                                                                                                LOG.info("*************************Dept Vendor Enriched ************************");
                                                                                                } catch (Exception e) {
                                                                                                                LOG.error(">>>>>>>>>>>>>>>>>>>>>>>>>" + e.getMessage());
                                                                                                }
                                                                                }

                                                                                @ProcessElement
                                                                                public void processElement(ProcessContext c) {
                                                                                                KV<String, Iterable<Row>> keyValuepair = c.element();
                                                                                                long invScanGrpId = Long.parseLong(keyValuepair.getKey());
                                                                                                Iterable<Row> inputRow = keyValuepair.getValue();
                                                                                                Stream<Row> result = StreamSupport.stream(inputRow.spliterator(), false);
                                                                                                List<String> skuUpcNbrList = result.map(entry -> entry.getString("SKU_UPC_NBR"))
                                                                                                                                .collect(Collectors.toList());
                                                                                                List<Long> longArrayList = skuUpcNbrList.stream().map(Long::parseLong)
                                                                                                                                .collect(Collectors.toList());
                                                                                                long skuUpcNbr = 0;
                                                                                                long deptNbr = 0;
                                                                                                long vndNbr = 0;
                                                                                                Map<String, String> materDataMap = new HashMap<>();
                                                                                                Statement stmtToChkDeptVnd = Statement
                                                                                                                                .newBuilder("select InvScanGrpId , ps.skuupcnbr, dvn.deptnbr, dvn.vndnbr "
                                                                                                                                                                + "from InvScanGrp grp "
                                                                                                                                                                + "join targetCntByDVN dvn on (dvn.ZlDivnNbr = grp.ZlDivnnbr and dvn.ZlStoreNbr = grp.ZlStoreNbr and dvn.CountDate = grp.CountDate) "
                                                                                                                                                                + "join prodsku ps on (ps.ZlDivnNbr = dvn.ZldivnNbr and ps.DeptNbr = dvn.DeptNbr and ps.VndNbr = dvn.vndnbr  and skuupcnbr in UNNEST( @skuUpcNbr) ) "
                                                                                                                                                                + "where grp.invscangrpid = @invScanGrpId ")
                                                                                                                                .bind("invScanGrpId").to(invScanGrpId).bind("skuUpcNbr").toInt64Array(longArrayList)
                                                                                                                                .build();
                                                                                                // LOG.info("Statement:::::::::" + stmtToChkDeptVnd.toString());
                                                                                                ResultSet resultSet = dbClient.singleUseReadOnlyTransaction().executeQuery(stmtToChkDeptVnd);
                                                                                                // LOG.info("Statement:::::::::");
                                                                                                while (resultSet.next()) {
                                                                                                                Struct row = resultSet.getCurrentRowAsStruct();
                                                                                                                // LOG.info("Rows>>>>>>>>>>>>>>>>>>>>>>>>>>:::::::::" + row);
                                                                                                                deptNbr = row.getLong("deptnbr");
                                                                                                                vndNbr = row.getLong("vndnbr");
                                                                                                                skuUpcNbr = row.getLong("skuupcnbr");
// LOG.info("Statement:::::::::" + skuUpcNbr);
                                                                                                                materDataMap.put(String.valueOf(skuUpcNbr), (deptNbr + "_" + vndNbr));
                                                                                                }
                                                                                                resultSet.close();
                                                                                                Iterable<Row> inputRow1 = c.element().getValue();
                                                                                                Stream<Row> result1 = StreamSupport.stream(inputRow1.spliterator(), false);
                                                                                                result1.filter(entry -> entry != null)
                                                                                                                                .forEach(n -> c.output(n.withSchema(rfidScanEpcDataSchema)
                                                                                                                                                                .withFieldValue("SCAN_TS", n.getString("SCAN_TS"))
                                                                                                                                                                .withFieldValue("USER_ID", n.getString("USER_ID"))
                                                                                                                                                                .withFieldValue("SKU_UPC_NBR", n.getString("SKU_UPC_NBR"))
                                                                                                                                                                .withFieldValue("EPC_URN", n.getString("EPC_URN"))
                                                                                                                                                                .withFieldValue("EPC_HEX", n.getString("EPC_HEX"))
                                                                                                                                                                .withFieldValue("INV_SCAN_HDR_ID", n.getString("INV_SCAN_HDR_ID"))
                                                                                                                                                                .withFieldValue("INV_SCAN_GRP_ID", n.getString("INV_SCAN_GRP_ID"))
                                                                                                                                                                .withFieldValue("DEPT_NBR",
                                                                                                                                                                                                materDataMap.get(n.getString("SKU_UPC_NBR")) != null
                                                                                                                                                                                                                                ? materDataMap.get(n.getString("SKU_UPC_NBR")).split("_")[0]
                                                                                                                                                                                                                                : "0")
                                                                                                                                                                .withFieldValue("VND_NBR",
                                                                                                                                                                                                materDataMap.get(n.getString("SKU_UPC_NBR")) != null
                                                                                                                                                                                                                                ? materDataMap.get(n.getString("SKU_UPC_NBR")).split("_")[1]
                                                                                                                                                                                                                                : "0")
                                                                                                                                                                .build()));
                                                                                                materDataMap.clear();
// LOG.info("DeptVendor jsonString : ");
                                                                                }
                                                                }));
                                PCollection<Void> invScanEpsInsert = deptVndEnriched.setCoder(RowCoder.of(rfidScanEpcDataSchema))
                                                                .apply("CreateScanDataMutation", ParDo.of(new DoFn<Row, Mutation>() {
                                                                                @ProcessElement
                                                                                public void processElement(ProcessContext c) {
                                                                                                Row inputRow = c.element();
                                                                                                long scnGrpId = Long.parseLong(inputRow.getString("INV_SCAN_GRP_ID"));
                                                                                                long hdrId = Long.parseLong(inputRow.getString("INV_SCAN_HDR_ID"));
                                                                                                long skuUpcNmbr = 0;
                                                                                                try {
                                                                                                                skuUpcNmbr = Long.parseLong(inputRow.getString("SKU_UPC_NBR"));
                                                                                                } catch (Exception e) {
                                                                                                                LOG.error("SKU UPC Number Invalid");
                                                                                                }
                                                                                                com.google.cloud.Timestamp scanTs = com.google.cloud.Timestamp
                                                                                                                                .parseTimestamp(inputRow.getString("SCAN_TS"));
                                                                                                Mutation scanDataMutation = Mutation.newInsertOrUpdateBuilder("InvScanEpc").set("InvScanGrpID")
                                                                                                                                .to(scnGrpId).set("EpcHex").to(inputRow.getString("EPC_HEX")).set("DeptNbr")
                                                                                                                                .to(inputRow.getString("DEPT_NBR")).set("EpcUrn").to(inputRow.getString("EPC_URN"))
                                                                                                                                .set("InvScanHdrID").to(hdrId).set("RunID").to(0).set("ScanTS").to(scanTs)
                                                                                                                                .set("SkuUpcNbr").to(skuUpcNmbr).set("UserID").to(inputRow.getString("USER_ID"))
                                                                                                                                .set("VndNbr").to(inputRow.getString("VND_NBR")).build();
                                                                                                c.output(scanDataMutation);
                                                                                }
                                                                }))
// Finally write the Mutations to Spanner
//                    scanDataMutations
                                                                .apply("WriteScanData",
                                                                                                SpannerIO.write().withInstanceId(SPANNER_INSTANCE_ID).withDatabaseId(SPANNER_DATABASE_ID))
                                                                .getOutput();
                                PCollection<String> distinctHdrId = deptVndEnriched.apply("GetSCnHdrId", ParDo.of(new DoFn<Row, String>() {
                                                @ProcessElement
                                                public void processElement(ProcessContext c) {
                                                                Row inputRow = c.element();
                                                                c.output(inputRow.getString("INV_SCAN_HDR_ID"));
                                                }
                                })).apply(Distinct.<String>create());
                                
                                PCollection<String> groupCountCollection = rfidScanPipeline.apply(GenerateSequence.from(0).withRate(1, Duration.standardSeconds(60L)))
                                                                .apply(Window.<Long>into(new GlobalWindows())
                                                                                                .triggering(Repeatedly.forever(AfterProcessingTime.pastFirstElementInPane()))
                                                                                                .discardingFiredPanes())
                                                                .apply("TakeGroupCount", ParDo.of(new DoFn<Long, String>() {
                                                                                private Spanner spanner = null;
                                                                                private DatabaseClient dbClient = null;

                                                                                @StartBundle
                                                                                public void startBundle(StartBundleContext c) {
                                                                                                com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
                                                                                                                                .newBuilder().build();
                                                                                                spanner = spannerOptions.getService();
                                                                                                String spannerProjectID = SPANNER_PROJECT_ID;
                                                                                                String spannerInstanceID = SPANNER_INSTANCE_ID;
                                                                                                String spannerDatabaseID = SPANNER_DATABASE_ID;
                                                                                                DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
                                                                                                dbClient = spanner.getDatabaseClient(db);
                                                                                }

                                                                                @FinishBundle
                                                                                public void finishBundle(FinishBundleContext c) {
                                                                                                dbClient = null;
                                                                                                spanner.close();
                                                                                }

                                                                                @ProcessElement
                                                                                public void processElement(ProcessContext c) {
                                                                                                Statement stmntForGroupCount = Statement.newBuilder(
                                                                                                                                "select epc.InvScanHdrID, count(1) as groupCount from InvScanEpc epc , invscanhdr hdr where  hdr.invScanhdrId = epc.invscanhdrid and hdr.invscanhdrstatus = 'Scanning'  group by epc.InvScanHdrID")
                                                                                                                                .build();
                                                                                                ResultSet resultSet = dbClient.singleUseReadOnlyTransaction().executeQuery(stmntForGroupCount);
                                                                                                while (resultSet.next()) {
                                                                                                                Struct row = resultSet.getCurrentRowAsStruct();
                                                                                                                String jsonString = "INV_SCAN_HDR_ID:" + row.getLong("InvScanHdrID")
                                                                                                                                                + ",MESSAGE_TYPE:group-count,SCAN_COUNT:" + row.getLong("groupCount");
                                                                                                                LOG.info("\nWriting to Group Count Pubusb::" + jsonString);
                                                                                                                c.output(jsonString);
                                                                                                }
                                                                                                resultSet.close();
                                                                                }
                                                                }));
                                groupCountCollection.apply("WriteCountToPubsub",
                                                                                                PubsubIO.writeStrings().to(configProperties.getProperty("group.count.topic.name")));
                                
                                groupCountCollection.apply(ParDo.of(new DoFn<String, Mutation>() {
                                                @ProcessElement
                                                public void processElement(ProcessContext c) {
                                                                String jsonStr = c.element();
                                                                if(null != jsonStr) {
                                                                                String[] splittedVal = jsonStr.split(",");
                                                                                String[] invScanHdrIdStr = splittedVal[0].split(":");
                                                                                String[] groupCountStr = splittedVal[2].split(":");
                                                                                Mutation groupCountMutation = Mutation.newUpdateBuilder("InvScanHdr")
                                                    .set("InvScanHdrID").to(new Long(invScanHdrIdStr[1]).longValue())
                                                    .set("ScanCount").to(new Long(groupCountStr[1]).longValue())
                            .set("LastUpdTS").to(com.google.cloud.Timestamp.now())
                            .set("LastUpdUser").to("CycleCountDataFlow")
                                .build();
                                                                                c.output(groupCountMutation);
                                                                }
                                                }
                                }))
                                .apply("WriteGroupCountToHeader", SpannerIO.write()
                                   .withInstanceId(SPANNER_INSTANCE_ID)
                                                  .withDatabaseId(SPANNER_DATABASE_ID));
                                

                                /*
                                * 
                                 * ------------------------Insertion into InvScanCntByDVN /InvScanCntBySku
                                * 
                                 * ----------------------------
                                * 
                                 */
                                rfidScanPipeline.apply(GenerateSequence.from(0).withRate(1, Duration.standardSeconds(60L)))
                                                                .apply(Window.<Long>into(new GlobalWindows())
                                                                                                .triggering(Repeatedly.forever(AfterProcessingTime.pastFirstElementInPane()))
                                                                                                .discardingFiredPanes())
                                                                .apply("Insertion into InvScanCntByDVN /InvScanCntBySku", ParDo.of(new DoFn<Long, Mutation>() {
                                                                                private Spanner spanner = null;
                                                                                private DatabaseClient dbClient = null;
                                                                                long startTimeStamp = 0;
                                                                                long endTimeStamp = 0;

                                                                                @StartBundle
                                                                                public void startBundle(StartBundleContext c) {
                                                                                                com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
                                                                                                                                .newBuilder().build();
                                                                                                spanner = spannerOptions.getService();
                                                                                                String spannerProjectID = SPANNER_PROJECT_ID;
                                                                                                String spannerInstanceID = SPANNER_INSTANCE_ID;
                                                                                                String spannerDatabaseID = SPANNER_DATABASE_ID;
                                                                                                DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
                                                                                                dbClient = spanner.getDatabaseClient(db);
                                                                                                startTimeStamp = System.currentTimeMillis();
                                                                                                LOG.info("Updating RunId to WIP status " + new Date(startTimeStamp));
                                                                                                String updWipStatusSql = "update invscanepc set runid = 5 where runid = 0 ";
                                                                                                dbClient.executePartitionedUpdate(Statement.of(updWipStatusSql));
                                                                                }

                                                                                @FinishBundle
                                                                                public void finishBundle(FinishBundleContext c) {
                                                                                                String updCompletedStatusSql = "update invscanepc set runid = 10 where runid = 5 ";
                                                                                                dbClient.executePartitionedUpdate(Statement.of(updCompletedStatusSql));
                                                                                                endTimeStamp = System.currentTimeMillis();
                                                                                                LOG.info("Updated RunId to completion status " + new Date(endTimeStamp) + " ...... Time taken :"
                                                                                                                                + ((endTimeStamp - startTimeStamp) / 1000) + " seconds ..");
                                                                                                dbClient = null;
                                                                                                spanner.close();
                                                                                }

                                                                                @ProcessElement
                                                                                public void processElement(ProcessContext c) {
                                                                                                LOG.info("cntbysku & ByDVN update in progress.. ");

                                                                                                Statement cntByDeptVndStmt = Statement.newBuilder(
                                                                                                                                "SELECT epcs.invscangrpid, epcs.deptnbr, epcs.vndnbr, (epcs.scancount + coalesce(iscd.scancount,0)) as scancount "
                                                                                                                                                                + "                from (SELECT invscangrpid, deptnbr, vndnbr, count(1) as scancount  "
                                                                                                                                                                + "                FROM InvScanepc epc " + "                where RunID = 5  "
                                                                                                                                                                + "               group by invscangrpid, deptnbr, vndnbr ) epcs "
                                                                                                                                                                + "                 left join InvScanCntbyDVN iscd on (iscd.invscangrpid = epcs.invscangrpid and  "
                                                                                                                                                                + "                 iscd.deptnbr = epcs.deptnbr and iscd.vndnbr = epcs.vndnbr) ")
                                                                                                                                .build();

//         LOG.info("Count By DVN Statement:::::::::"+ cntByDeptVndStmt.toString());
                                                                                                ResultSet resultSet = dbClient.singleUseReadOnlyTransaction().executeQuery(cntByDeptVndStmt);
                                                                                                while (resultSet.next()) {
                                                                                                                Struct row = resultSet.getCurrentRowAsStruct();

                                                                                                                Mutation byDVNMutation = Mutation.newInsertOrUpdateBuilder("InvScanCntbyDVN")
                                                                                                                                                .set("InvScanGrpID").to(row.getLong("invscangrpid")).set("DeptNbr")
                                                                                                                                                .to(row.getLong("deptnbr")).set("VndNbr").to(row.getLong("vndnbr")).set("ScanCount")
                                                                                                                                                .to(row.getLong("scancount")).build();

//          LOG.info("Count By DVN Mutation convertor----------------->>>"+byDVNMutation.toString());
                                                                                                                c.output(byDVNMutation);

                                                                                                }
                                                                                                resultSet.close();

                                                                                                Statement cntBySkuStmt = Statement.newBuilder(
                                                                                                                                "SELECT epcs.invscangrpid, epcs.deptnbr, epcs.vndnbr, epcs.skuupcnbr, (epcs.scancount + coalesce(iscs.scancount,0)) as scancount "
                                                                                                                                                                + "                from (SELECT invscangrpid, deptnbr, vndnbr, skuupcnbr, count(1) as scancount  "
                                                                                                                                                                + "                FROM InvScanepc epc " + "                where RunID =  5 "
                                                                                                                                                                + " group by invscangrpid, deptnbr, vndnbr, skuupcnbr ) epcs "
                                                                                                                                                                + "                 left join invscancntbysku iscs on (iscs.invscangrpid = epcs.invscangrpid and  "
                                                                                                                                                                + "                 iscs.deptnbr = epcs.deptnbr and iscs.vndnbr = epcs.vndnbr and  iscs.skuupcnbr =  epcs.skuupcnbr)")
                                                                                                                                .build();

//         LOG.info("Count By SKU Statement:::::::::"+ cntBySkuStmt.toString());
                                                                                                ResultSet cntBySkuResultSet = dbClient.singleUseReadOnlyTransaction()
                                                                                                                                .executeQuery(cntBySkuStmt);
                                                                                                while (cntBySkuResultSet.next()) {
                                                                                                                Struct row = cntBySkuResultSet.getCurrentRowAsStruct();

                                                                                                                Mutation cntBySkuMutation = Mutation.newInsertOrUpdateBuilder("InvScanCntbySKU")
                                                                                                                                                .set("InvScanGrpID").to(row.getLong("invscangrpid")).set("DeptNbr")
                                                                                                                                                .to(row.getLong("deptnbr")).set("VndNbr").to(row.getLong("vndnbr")).set("skuupcnbr")
                                                                                                                                                .to(row.getLong("skuupcnbr")).set("ScanCount").to(row.getLong("scancount")).build();

//          LOG.info("Count By SKU Mutation convertor----------------->>>"+cntBySkuMutation.toString());
                                                                                                                c.output(cntBySkuMutation);

                                                                                                }
                                                                                                resultSet.close();
                                                                                }
                                                                })).apply("WriteScanData",
                                                                                                SpannerIO.write().withInstanceId(SPANNER_INSTANCE_ID).withDatabaseId(SPANNER_DATABASE_ID));
                                rfidScanPipeline
                                                                .apply("ReadNotificationPubsub", PubsubIO.readStrings().fromSubscription(
                                                                                                configProperties.getProperty("submit.notification.dev")))
                                                                .apply("JSONToRow", JsonToRow.withSchema(notificationSchema)).apply(ParDo.of(new DoFn<Row, String>() {
                                                                                private Spanner spanner = null;
                                                                                private DatabaseClient dbClient = null;

                                                                                @StartBundle
                                                                                public void startBundle(StartBundleContext c) {
// TransactionFileOptions options =
// c.getPipelineOptions().as(TransactionFileOptions.class);
                                                                                                com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
                                                                                                                                .newBuilder().build();
                                                                                                spanner = spannerOptions.getService();
                                                                                                String spannerProjectID = SPANNER_PROJECT_ID;
                                                                                                String spannerInstanceID = SPANNER_INSTANCE_ID;
                                                                                                String spannerDatabaseID = SPANNER_DATABASE_ID;
                                                                                                DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
                                                                                                dbClient = spanner.getDatabaseClient(db);
                                                                                }

                                                                                @FinishBundle
                                                                                public void finishBundle(FinishBundleContext c) {
                                                                                                dbClient = null;
                                                                                                spanner.close();
                                                                                }

                                                                                @ProcessElement
                                                                                public void processElement(ProcessContext c) {
                                                                                                LOG.info("\nData from notification pubsub:::::::::" + c.element().toString());
                                                                                                Row inputRow = c.element();
                                                                                                String actionRequest = inputRow.getString("actionRequest");
                                                                                                long InvScanHdrID = inputRow.getInt64("scanSessionId");
                                                                                                String userId = inputRow.getString("userId");
                                                                                                if (actionRequest.equalsIgnoreCase("done")) {
                                                                                                                long actualCount = 0;
                                                                                                                long totalCount = 0;
                                                                                                                Statement stmntForActualCount = Statement.newBuilder(
                                                                                                                                                "select InvScanHdrID,count(*) as actualCount from InvScanEpc where InvScanHdrID = @inscanHeaderId and DeptNbr!=0 and VndNbr!=0  group by InvScanHdrID")
                                                                                                                                                .bind("inscanHeaderId").to(InvScanHdrID).build();
                                                                                                                ResultSet resultSet = dbClient.singleUseReadOnlyTransaction()
                                                                                                                                                .executeQuery(stmntForActualCount);
                                                                                                                if (resultSet.next()) {
                                                                                                                                Struct row = resultSet.getCurrentRowAsStruct();
                                                                                                                                actualCount = row.getLong("actualCount");
// LOG.info("Data::" + row.getLong("actualCount") + "::" + row.getLong("InvScanHdrID"));
                                                                                                                }
                                                                                                                resultSet.close();
                                                                                                                Statement stmntForTotalCount = Statement.newBuilder(
                                                                                                                                                "select InvScanHdrID,count(*) as totalCount from InvScanEpc where InvScanHdrID = @inscanHeaderId group by InvScanHdrID")
                                                                                                                                                .bind("inscanHeaderId").to(InvScanHdrID).build();
                                                                                                                ResultSet resultSetTotalCount = dbClient.singleUseReadOnlyTransaction()
                                                                                                                                                .executeQuery(stmntForTotalCount);
                                                                                                                if (resultSetTotalCount.next()) {
                                                                                                                                Struct row = resultSetTotalCount.getCurrentRowAsStruct();
                                                                                                                                totalCount = row.getLong("totalCount");
                                                                                // LOG.info("TotalCount::" + row.getLong("totalCount") + "::"
                                                                                // + row.getLong("InvScanHdrID"));
                                                                                                                }
                                                                                                                resultSetTotalCount.close();
                                                                                                                String scanSummary = "INV_SCAN_HDR_ID:" + InvScanHdrID
                                                                                                                                                + ",MESSAGE_TYPE:scan-summary,SCAN_COUNT:" + totalCount + ",USER_ID:" + userId
                                                                                                                                                + ",EXPECTED_ITEMS_COUNT:" + actualCount;
                                                                                                                LOG.info("Publishing scan summary::" + scanSummary.toString());
                                                                                                                c.output(scanSummary);
                                                                                                }
                                                                                }
                                                                })).apply("WriteScanSummaryToPubsub",
                                                                                                PubsubIO.writeStrings().to(configProperties.getProperty("group.count.topic.name")));
                                rfidScanPipeline.run().waitUntilFinish();
                }
}
