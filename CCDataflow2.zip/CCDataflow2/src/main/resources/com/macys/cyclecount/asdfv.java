package com.macys.cyclecount;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.stream.StreamSupport;

import org.apache.beam.sdk.coders.KvCoder;
import org.apache.beam.sdk.coders.RowCoder;
import org.apache.beam.sdk.io.GenerateSequence;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.windowing.AfterProcessingTime;
import org.apache.beam.sdk.transforms.windowing.GlobalWindows;
import org.apache.beam.sdk.transforms.windowing.Repeatedly;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.Row;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.joda.time.Duration;

/* department vendor count starts here ..............................*/
final Schema rfidScanVendorKeyEpcDataSchema = Schema.builder().addStringField("DEPT_NBR").addStringField("VND_NBR")
		.build();


final PCollection<KV<Row, Row>> rfidScanVendorKeyEpcDataByKV = deptVndEnriched
		.apply("Set Group Id as  key",
				MapElements.into(TypeDescriptors.kvs(TypeDescriptors.rows(), TypeDescriptors.rows()))
				.via(row1 -> KV.of( Row
						.withSchema(rfidScanVendorKeyEpcDataSchema).addValues( row1.getString("DEPT_NBR"), row1.getString("VND_NBR")).build(), row1)));



final PCollection<KV<Row, Iterable<Row>>> rfidScanVendorKeyEpcDataaGroupedRecords7 = rfidScanVendorKeyEpcDataByKV
		.setCoder(KvCoder.of(RowCoder.of(rfidScanVendorKeyEpcDataSchema), RowCoder.of(rfidScanEpcDataSchema)))
		.apply(GroupByKey.<Row, Row>create());


rfidScanVendorKeyEpcDataaGroupedRecords7.apply(ParDo.of(new DoFn<KV<Row, Iterable<Row>>, Void>() {
	@ProcessElement
	public void processElement(ProcessContext c) {

		final KV<Row, Iterable<Row>> message = c.element();
		final long count = StreamSupport.stream(message.getValue().spliterator(), false).count();
		final String epcHex = message.getKey().getString("DEPT_NBR")+"_"+message.getKey().getString("VND_NBR");
		System.out.println(epcHex+"MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMm"+count);

		//c.output(data);
	}
}));
/* department vendor count ends here ..............................*/

/* sku count starts here ..............................*/
final Schema rfidScanVendorSKUCountSchema = Schema.builder().addStringField("DEPT_NBR").addStringField("VND_NBR").addStringField("SKU_UPC_NBR").addStringField("INV_SCAN_GRP_ID").addInt64Field("TIME_STAMP")
		.build();


final PCollection<KV<Row, Row>> rfidScanVendorSKUEpcDataByKV = deptVndEnriched
		.apply("Set Group Id as  key",
				MapElements.into(TypeDescriptors.kvs(TypeDescriptors.rows(), TypeDescriptors.rows()))
				.via(row1 -> KV.of( Row
						.withSchema(rfidScanVendorSKUCountSchema).addValues( row1.getString("DEPT_NBR"), row1.getString("VND_NBR"),row1.getString("SKU_UPC_NBR"),row1.getString("INV_SCAN_GRP_ID"),new Long(System.currentTimeMillis())).build(), row1)));



final PCollection<KV<Row, Iterable<Row>>> rfidScanVendorSKUDataaGroupedRecords7 = rfidScanVendorSKUEpcDataByKV
		.setCoder(KvCoder.of(RowCoder.of(rfidScanVendorSKUCountSchema), RowCoder.of(rfidScanEpcDataSchema)))
		.apply(GroupByKey.<Row, Row>create());


rfidScanVendorSKUDataaGroupedRecords7.apply(ParDo.of(new DoFn<KV<Row, Iterable<Row>>, Void>() {
	
	@ProcessElement
	public void processElement(ProcessContext c) {
		System.out.println(dvnMap+"dvnMap>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>."+dvnMap.size());

		final KV<Row, Iterable<Row>> message = c.element();
		final long count = StreamSupport.stream(message.getValue().spliterator(), false).count();
		final String key = message.getKey().getString("INV_SCAN_GRP_ID")+"_"+message.getKey().getString("DEPT_NBR")+"_"+message.getKey().getString("VND_NBR")+"_"+message.getKey().getString("SKU_UPC_NBR")+"_"+message.getKey().getInt64("TIME_STAMP");
		System.out.println(key+"MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMm"+count);

		dvnMap.put(key, count);

		System.out.println(key+"Sku>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+dvnMap.get(key));

		//c.output(data);
	}
}));


rfidScanPipeline
.apply(GenerateSequence.from(0).withRate(1, Duration.standardSeconds(60L)))
.apply(
		Window.<Long>into(new GlobalWindows())
		.triggering(Repeatedly.forever(AfterProcessingTime.pastFirstElementInPane()))
		.discardingFiredPanes())
.apply("aggregate count", ParDo.of(new DoFn<Long, String>() {

	@ProcessElement
	public void processElement(ProcessContext c) {
		 // Get the iterator over the HashMap 
        Iterator<Entry<String, Long>> 
            iterator = dvnMap.entrySet().iterator(); 
  
        // Iterate over the HashMap 
        while (iterator.hasNext()) { 
  
            // Get the entry at this iteration 
            Entry<String, Long> 
                entry 
                = iterator.next(); 
            System.out.println(entry.getKey()+"<><><><>agreeeeeeeeeeeeeeeee>>>>>>>>>>>>>>>>>>>"+entry.getKey());
            // Check if this key is the required key 
           // if (keyToBeRemoved == entry.getKey()) { 
  
                // Remove this entry from HashMap 
                iterator.remove(); 
           // } 
        } 


	}
}));



