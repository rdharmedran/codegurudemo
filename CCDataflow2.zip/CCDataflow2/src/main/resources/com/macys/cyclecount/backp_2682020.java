package com.macys.cyclecount;
package com.macys.cyclecount;


/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.KvCoder;
import org.apache.beam.sdk.coders.RowCoder;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.GenerateSequence;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.transforms.Distinct;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.JsonToRow;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.windowing.AfterProcessingTime;
import org.apache.beam.sdk.transforms.windowing.AfterWatermark;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.GlobalWindows;
import org.apache.beam.sdk.transforms.windowing.Repeatedly;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.Row;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.joda.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;

import avro.shaded.com.google.common.collect.Lists;

/**
 * RFID Scanning Dataflow to read data from pubsub and write data
 *
 *
 */
public class RFIDCycleCountStarter7 {
	private static final Logger LOG = LoggerFactory.getLogger(RFIDCycleCountStarter.class);

	public static void main(String[] args) throws Exception {
		final PipelineOptions options = PipelineOptionsFactory.create();

		/*
		 * DataflowPipelineOptions options =
		 * PipelineOptionsFactory.as(DataflowPipelineOptions.class);
		 * options.setProject("mtech-storesys-np");
		 * options.setStagingLocation("gs://storesys-rfid-np/Dataflow/staging-aug-18/");
		 * options.setRunner(DataflowRunner.class); options.setTemplateLocation(
		 * "gs://storesys-rfid-np/Dataflow/templates-aug-18/RFID-CycleCount-Dataflow-dev"
		 * ); options.setRegion("us-central1");
		 * options.setTempLocation("gs://storesys-rfid-np/Dataflow/temp/");
		 */
Map<String,Long> dvnMap=new HashMap<>();
Map<String,Long> skudvnMap=new HashMap<>();
		final Pipeline rfidScanPipeline = Pipeline.create(options);
		LOG.info(rfidScanPipeline.getCoderRegistry().getCoder(Void.class).toString());
		LOG.info("Pipeline created");

		final Schema rfidScanDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")
				.addStringField("USER_ID").addStringField("EPC_HEX").addStringField("EPC_URN")
				.addStringField("SKU_UPC_NBR").addStringField("SCAN_TS").build();

		final Schema rfidScanEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
				.addStringField("INV_SCAN_HDR_ID").addStringField("USER_ID").addStringField("EPC_HEX")
				.addStringField("EPC_URN").addStringField("DEPT_NBR").addStringField("VND_NBR")
				.addStringField("SKU_UPC_NBR").addStringField("SCAN_TS").build();



		final Schema notificationSchema = Schema.builder().addInt64Field("scanSessionId").addStringField("actionRequest")
				.addStringField("userId").build();

		Properties configProperties = null;
		try {
			configProperties = RFIDCycleCountUtil.readPropertiesFile();
		} catch (final IOException e) {
			LOG.error("Error reading configuration file::" + e);
		}

		final PCollectionView<Map<String, String>> displayEpcMap = rfidScanPipeline
				.apply(GenerateSequence.from(0).withRate(1, Duration.standardSeconds(3600L)))
				.apply(Window.<Long>into(new GlobalWindows())
						.triggering(Repeatedly.forever(AfterProcessingTime.pastFirstElementInPane()))
						.discardingFiredPanes())
				.apply(ParDo.of(new DoFn<Long, KV<String, String>>() {
					private Spanner spanner = null;
					private DatabaseClient dbClient = null;

					@StartBundle
					public void startBundle(StartBundleContext c) {
						final com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
								.newBuilder().build();
						spanner = spannerOptions.getService();
						final String spannerProjectID = "mtech-storesys-np";
						final String spannerInstanceID = "cspanner-storesys-np";
						final String spannerDatabaseID = "rfid-db-dev";

						final DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
						dbClient = spanner.getDatabaseClient(db);
					}

					@FinishBundle
					public void finishBundle(FinishBundleContext c) {
						try {
							dbClient = null;
							spanner.close();
						} catch (final Exception e) {
							LOG.error(">>>>>>>>>>>>>>>>>>>>>>>>>" + e.getMessage());
						}
					}

					@ProcessElement
					public void processElement(ProcessContext c) {

						final Statement stmtTogetDisplayEpc = Statement.newBuilder(
								"Select tw.ZlDivnNbr,tw.ZlStorenbr,  tw.EpcHex from tagswritten tw  Where tw.ActiveFlag = 'A' and tw.zldivnnbr = 71 and TW.zlstorenbr = 733 and (tw.ZoneName ) in (Select  zn.ZoneName from RfidZone zn Where zn.ZoneType = 'Audit' and tw.ZlDivnNbr =  zn.ZlDivnNbr and zn.ZlStorenbr = tw.ZlStorenbr)  ")
								.build();

						LOG.info("Display Tag Statement:::::::::" + stmtTogetDisplayEpc.toString());
						final ResultSet resultSet = dbClient.singleUseReadOnlyTransaction().executeQuery(stmtTogetDisplayEpc);

						//				                     List<Row> displayEpcList = new ArrayList<Row>();

						while (resultSet.next()) {
							final Struct row = resultSet.getCurrentRowAsStruct();
									final String epcHex = row.getString(2);
							
							final Map<String, String> map = new HashMap<>();
							map.put(epcHex, epcHex);
							c.output(KV.of(epcHex, epcHex));
						}
						resultSet.close();
					}
				})).apply(View.<String, String>asMap());
		;

		final PCollection<PubsubMessage> scanMessage = rfidScanPipeline.apply("ReadPubsub",
				PubsubIO.readMessagesWithAttributes().withIdAttribute("UNIQUE_ID")
				// .fromSubscription("projects/mtech-storesys-np/subscriptions/test-rfid-pull"));
				.fromSubscription(configProperties.getProperty("device.scan.data.subscription.name")));

		/*
		 * ---------------------------------- group data test login for incoming message -----------------------------
		 */
		final PCollection<String> scanData = scanMessage.apply(ParDo.of(new DoFn<PubsubMessage, String>() {
			@ProcessElement
			public void processElement(ProcessContext c) {

				final PubsubMessage message = c.element();
				final String epcHex = message.getAttribute("UNIQUE_ID");
				final String data = new String(message.getPayload(), StandardCharsets.UTF_8);

				LOG.info(" Attribute:: " + epcHex);
				if(epcHex!=null)
					c.output(data);
			}
		}));
		/*
		 * ---------------------------------- group data test login for incoming message ends -----------------------------
		 */

		/*
		 * ---------------------------------- create micro batches for message with 30 seconds window-----------------------------
		 */
		final PCollection<String> windowedData = scanData.apply(Window
				.<String>into(FixedWindows.of(Duration.standardSeconds(30)))
				.triggering(AfterWatermark.pastEndOfWindow()
						.withEarlyFirings(
								AfterProcessingTime.pastFirstElementInPane().plusDelayOf(Duration.standardSeconds(30)))
						.withLateFirings(
								AfterProcessingTime.pastFirstElementInPane().plusDelayOf(Duration.standardSeconds(30))))
				.withAllowedLateness(Duration.standardSeconds(5)).discardingFiredPanes());

		/*
		 * ---------------------------------- create micro batches for message with 30 seconds window  ends -----------------------------
		 */

		/*
		 * ---------------------------------- Convert String message to Row -----------------------------
		 */
		final PCollection<Row> scanDataRow = windowedData.apply("JSONToRow", JsonToRow.withSchema(rfidScanDataSchema));
		/*
		 * ---------------------------------- Convert String message to Row  end -----------------------------
		 */

		/*
		 * ----------------------------------group the message with header id -----------------------------
		 */
		//convert to key value pair
		final PCollection<KV<String, Row>> scanDataRow7 = scanDataRow
				.apply("Set EPC Header Id as  key",
						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.strings(), TypeDescriptors.rows()))
						.via(row1 -> KV.of(row1.getString("INV_SCAN_HDR_ID"), row1)))
				.setRowSchema(rfidScanDataSchema);

		/*
		 * ----------------------------------group the message with header id  ends-----------------------------
		 */


		/*
		 * -------------------------------------- remove display tag from stream using
		 * filter --------------------------------------------
		 */
		final PCollection<KV<String, Iterable<Row>>> GroupedRecords7 = scanDataRow7
				.setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(rfidScanDataSchema)))
				.apply(GroupByKey.<String, Row>create());
		final PCollection<Row> displayremoved = GroupedRecords7.apply("FilterDisplay Tags",
				ParDo.of(new DoFn<KV<String, Iterable<Row>>, Row>() {
					@ProcessElement
					public void processElement(ProcessContext c) {
						final Map<String, String> sideInoput = c.sideInput(displayEpcMap);
						final Iterable<Row> inputRow = c.element().getValue();
						final Stream<Row> result = StreamSupport.stream(inputRow.spliterator(), false);

						result.filter(entry -> !sideInoput.containsKey(entry.getString("EPC_HEX")))
						.forEach(n -> c.output(n));


					}
				}).withSideInputs(displayEpcMap));

		// stream and remove display tag test
		displayremoved.setCoder(RowCoder.of(rfidScanDataSchema)).apply("FilterDisplay Tags",
				ParDo.of(new DoFn<Row, String>() {
					@ProcessElement
					public void processElement(ProcessContext c) {
						final Row inputRow = c.element();
						LOG.info("NonDisplay Tagsjs<>><<><>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<onString ::"
								+ inputRow.getString("EPC_HEX"));

					}
				}));
		/*
		 * ------------------------- Group the messages by group id
		 * ---------------------------------------------------------
		 */
		final PCollection<KV<String, Row>> displayremovedByKV = displayremoved
				.apply("Set Group Id as  key",
						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.strings(), TypeDescriptors.rows()))
						.via(row1 -> KV.of(row1.getString("INV_SCAN_GRP_ID"), row1)))
				.setRowSchema(rfidScanDataSchema);
		final PCollection<KV<String, Iterable<Row>>> displayremovedByGroupId = displayremovedByKV
				.setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(rfidScanDataSchema)))
				.apply(GroupByKey.<String, Row>create());

		/*
		 * ------------------------ populate vendor number and department number by
		 * micro batching based on group id ----------------------------
		 */
		final PCollection<Row> deptVndEnriched = displayremovedByGroupId
				.apply(ParDo.of(new DoFn<KV<String, Iterable<Row>>, Row>() {

					private Spanner spanner = null;
					private DatabaseClient dbClient = null;

					@StartBundle
					public void startBundle(StartBundleContext c) {
						// TransactionFileOptions options =
						// c.getPipelineOptions().as(TransactionFileOptions.class);

						final com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
								.newBuilder().build();
						spanner = spannerOptions.getService();
						final String spannerProjectID = "mtech-storesys-np";
						final String spannerInstanceID = "cspanner-storesys-np";
						final String spannerDatabaseID = "rfid-db-dev";

						final DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
						dbClient = spanner.getDatabaseClient(db);
					}

					@FinishBundle
					public void finishBundle(FinishBundleContext c) {
						try {
							dbClient = null;
							spanner.close();
						} catch (final Exception e) {
							LOG.error(">>>>>>>>>>>>>>>>>>>>>>>>>" + e.getMessage());
						}
					}

					@ProcessElement
					public void processElement(ProcessContext c) {

						final KV<String, Iterable<Row>> keyValuepair = c.element();
						final long invScanGrpId = Long.parseLong(keyValuepair.getKey());

						final Iterable<Row> inputRow = keyValuepair.getValue();
						final Stream<Row> result = StreamSupport.stream(inputRow.spliterator(), false);
						final List<String> skuUpcNbrList = result.map(entry -> entry.getString("SKU_UPC_NBR"))
								.collect(Collectors.toList());
						final List<Long> longArrayList = skuUpcNbrList.stream().map(Long::parseLong)
								.collect(Collectors.toList());
						long skuUpcNbr = 0;
						long deptNbr = 0;
						long vndNbr = 0;

						final Map<String, String> materDataMap = new HashMap<>();
						final Statement stmtToChkDeptVnd = Statement
								.newBuilder("select InvScanGrpId , ps.skuupcnbr, dvn.deptnbr, dvn.vndnbr "
										+ "from InvScanGrp grp "
										+ "join targetCntByDVN dvn on (dvn.ZlDivnNbr = grp.ZlDivnnbr and dvn.ZlStoreNbr = grp.ZlStoreNbr and dvn.CountDate = grp.CountDate) "
										+ "join prodsku ps on (ps.ZlDivnNbr = dvn.ZldivnNbr and ps.DeptNbr = dvn.DeptNbr and ps.VndNbr = dvn.vndnbr  and skuupcnbr in UNNEST( @skuUpcNbr) ) "
										+ "where grp.invscangrpid = @invScanGrpId ")
								.bind("invScanGrpId").to(invScanGrpId).bind("skuUpcNbr").toInt64Array(longArrayList)
								.build();

						LOG.info("Statement:::::::::" + stmtToChkDeptVnd.toString());
						final ResultSet resultSet = dbClient.singleUseReadOnlyTransaction().executeQuery(stmtToChkDeptVnd);
						LOG.info("Statement:::::::::");
						while (resultSet.next()) {
							final Struct row = resultSet.getCurrentRowAsStruct();
							LOG.info("Rows>>>>>>>>>>>>>>>>>>>>>>>>>>:::::::::" + row);
							deptNbr = row.getLong("deptnbr");
							vndNbr = row.getLong("vndnbr");
							skuUpcNbr = row.getLong("skuupcnbr");
							LOG.info("Statement:::::::::" + skuUpcNbr);

							materDataMap.put(String.valueOf(skuUpcNbr), deptNbr + "_" + vndNbr);

						}
						resultSet.close();
						final Iterable<Row> inputRow1 = c.element().getValue();
						final Stream<Row> result1 = StreamSupport.stream(inputRow1.spliterator(), false);

						result1.filter(entry ->entry!=null)
						.forEach(n -> c.output(Row.withSchema(rfidScanEpcDataSchema)
								.withFieldValue("SCAN_TS", n.getString("SCAN_TS"))
								.withFieldValue("USER_ID", n.getString("USER_ID"))
								.withFieldValue("SKU_UPC_NBR", n.getString("SKU_UPC_NBR"))
								.withFieldValue("EPC_URN", n.getString("EPC_URN"))
								.withFieldValue("EPC_HEX", n.getString("EPC_HEX"))
								.withFieldValue("INV_SCAN_HDR_ID", n.getString("INV_SCAN_HDR_ID"))
								.withFieldValue("INV_SCAN_GRP_ID", n.getString("INV_SCAN_GRP_ID"))
								.withFieldValue("DEPT_NBR",
										materDataMap.get(n.getString("SKU_UPC_NBR"))!=null?materDataMap.get(n.getString("SKU_UPC_NBR")).split("_")[0]:"0")
								.withFieldValue("VND_NBR",
										materDataMap.get(n.getString("SKU_UPC_NBR"))!=null?materDataMap.get(n.getString("SKU_UPC_NBR")).split("_")[1]:"0")
								.build()));
						materDataMap.clear();
						LOG.info("DeptVendor jsonString : ");

					}
				}));
		deptVndEnriched.setCoder(RowCoder.of(rfidScanEpcDataSchema))
		.apply("CreateScanDataMutation", ParDo.of(new DoFn<Row, Mutation>() {
			@ProcessElement
			public void processElement(ProcessContext c) {
				final Row inputRow = c.element();
				final long scnGrpId = Long.parseLong(inputRow.getString("INV_SCAN_GRP_ID"));
				final long hdrId = Long.parseLong(inputRow.getString("INV_SCAN_HDR_ID"));
				long skuUpcNmbr = 0;
				try {
					skuUpcNmbr = Long.parseLong(inputRow.getString("SKU_UPC_NBR"));
				} catch (final Exception e) {
					LOG.error("SKU UPC Number Invalid");
				}
				// OffsetDateTime odtInstanceAtOffset =
				// OffsetDateTime.parse(inputRow.getString("SCAN_TS"), DATE_TIME_FORMATTER);

				final com.google.cloud.Timestamp scanTs = com.google.cloud.Timestamp
						.parseTimestamp(inputRow.getString("SCAN_TS"));

				final Mutation scanDataMutation = Mutation.newInsertOrUpdateBuilder("InvScanEpc").set("InvScanGrpID")
						.to(scnGrpId).set("EpcHex").to(inputRow.getString("EPC_HEX")).set("DeptNbr")
						.to(inputRow.getString("DEPT_NBR")).set("EpcUrn").to(inputRow.getString("EPC_URN"))
						.set("InvScanHdrID").to(hdrId).set("RunID").to(0).set("ScanTS").to(scanTs)
						.set("SkuUpcNbr").to(skuUpcNmbr).set("UserID").to(inputRow.getString("USER_ID"))
						.set("VndNbr").to(inputRow.getString("VND_NBR"))

						.build();
				LOG.info("Mutation convertor----------------->>>" + scanDataMutation.toString());
				c.output(scanDataMutation);
			}
		}))
		// Finally write the Mutations to Spanner
		//		        scanDataMutations
		.apply("WriteScanData",
				SpannerIO.write().withInstanceId("cspanner-storesys-np").withDatabaseId("rfid-db-dev"))
		.getOutput();
		deptVndEnriched.apply("GetSCnHdrId", ParDo.of(new DoFn<Row, String>() {
			@ProcessElement
			public void processElement(ProcessContext c) {
				final Row inputRow = c.element();
				c.output(inputRow.getString("INV_SCAN_HDR_ID"));
			}
		})).apply(Distinct.<String>create());

		/* department vendor count starts here ..............................*/
		final Schema rfidScanVendorKeyEpcDataSchema = Schema.builder().addStringField("DEPT_NBR").addStringField("VND_NBR")
				.build();


		final PCollection<KV<Row, Row>> rfidScanVendorKeyEpcDataByKV = deptVndEnriched
				.apply("Set Group Id as  key",
						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.rows(), TypeDescriptors.rows()))
						.via(row1 -> KV.of( Row
								.withSchema(rfidScanVendorKeyEpcDataSchema).addValues( row1.getString("DEPT_NBR"), row1.getString("VND_NBR")).build(), row1)));



		final PCollection<KV<Row, Iterable<Row>>> rfidScanVendorKeyEpcDataaGroupedRecords7 = rfidScanVendorKeyEpcDataByKV
				.setCoder(KvCoder.of(RowCoder.of(rfidScanVendorKeyEpcDataSchema), RowCoder.of(rfidScanEpcDataSchema)))
				.apply(GroupByKey.<Row, Row>create());


		rfidScanVendorKeyEpcDataaGroupedRecords7.apply(ParDo.of(new DoFn<KV<Row, Iterable<Row>>, Void>() {
			@ProcessElement
			public void processElement(ProcessContext c) {

				final KV<Row, Iterable<Row>> message = c.element();
				final long count = StreamSupport.stream(message.getValue().spliterator(), false).count();
				final String epcHex = message.getKey().getString("DEPT_NBR")+"_"+message.getKey().getString("VND_NBR");
				System.out.println(epcHex+"MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMm"+count);

				//c.output(data);
			}
		}));
		/* department vendor count ends here ..............................*/

		/* sku count starts here ..............................*/
		final Schema rfidScanVendorSKUCountSchema = Schema.builder().addStringField("DEPT_NBR").addStringField("VND_NBR").addStringField("SKU_UPC_NBR").addStringField("INV_SCAN_GRP_ID")
				.build();


		final PCollection<KV<Row, Row>> rfidScanVendorSKUEpcDataByKV = deptVndEnriched
				.apply("Set Group Id as  key",
						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.rows(), TypeDescriptors.rows()))
						.via(row1 -> KV.of( Row
								.withSchema(rfidScanVendorSKUCountSchema).addValues( row1.getString("DEPT_NBR"), row1.getString("VND_NBR"),row1.getString("SKU_UPC_NBR"),row1.getString("INV_SCAN_GRP_ID")).build(), row1)));



		final PCollection<KV<Row, Iterable<Row>>> rfidScanVendorSKUDataaGroupedRecords7 = rfidScanVendorSKUEpcDataByKV
				.setCoder(KvCoder.of(RowCoder.of(rfidScanVendorSKUCountSchema), RowCoder.of(rfidScanEpcDataSchema)))
				.apply(GroupByKey.<Row, Row>create());


		rfidScanVendorSKUDataaGroupedRecords7.apply(ParDo.of(new DoFn<KV<Row, Iterable<Row>>, Void>() {
			private DatabaseClient dbClient = null;
			private Spanner spanner = null;
			@StartBundle
			public void startBundle(StartBundleContext c) {
				// TransactionFileOptions options =
				// c.getPipelineOptions().as(TransactionFileOptions.class);

				final com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
						.newBuilder().build();
				spanner = spannerOptions.getService();
				final String spannerProjectID = "mtech-storesys-np";
				final String spannerInstanceID = "cspanner-storesys-np";
				final String spannerDatabaseID = "rfid-db-dev";

				final DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
				dbClient = spanner.getDatabaseClient(db);
			}

			@FinishBundle
			public void finishBundle(FinishBundleContext c) {
				try {
					dbClient = null;
					spanner.close();
				} catch (final Exception e) {
					LOG.error(">>>>>>>>>>>>>>>>>>>>>>>>>" + e.getMessage());
				}
			}

			@ProcessElement
			public void processElement(ProcessContext c) {

				final KV<Row, Iterable<Row>> message = c.element();
				final long count = StreamSupport.stream(message.getValue().spliterator(), false).count();
				final Statement stmtToChkDeptVnd = Statement
						.newBuilder("SELECT invscangrpid, deptnbr, vndnbr, skuupcnbr, scancount " +
								"                from 	invscancntbysku  where invscangrpid = @invScanGrpId and \r\n" +
								"                 deptnbr = @deptnbr and vndnbr = @vndnbr and  skuupcnbr =  @skuupcnbr")
						.bind("deptnbr").to(Long.parseLong(message.getKey().getString("DEPT_NBR"))).bind("skuupcnbr").to(Long.parseLong(message.getKey().getString("SKU_UPC_NBR")))
						.bind("vndnbr").to(Long.parseLong(message.getKey().getString("VND_NBR"))).bind("invScanGrpId").to(Long.parseLong(message.getKey().getString("INV_SCAN_GRP_ID")))
						.build();

				LOG.info("Statement:::::::::" + stmtToChkDeptVnd.toString());
				final ResultSet resultSet = dbClient.singleUseReadOnlyTransaction().executeQuery(stmtToChkDeptVnd);
				LOG.info("Statement:::::::::");
				while (resultSet.next()) {
					final Struct row = resultSet.getCurrentRowAsStruct();
					LOG.info("Rows>>>>>>>>>>>>>>>>>>>>>>>>>>:::::::::" + row);
					row.getLong("deptnbr");
					row.getLong("vndnbr");
					final long skuUpcNbr = row.getLong("skuupcnbr");
					final long scancount = row.getLong("scancount");
					LOG.info("Statement:::::::::" + skuUpcNbr);

					System.out.println("Scan Coun bySKU >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+scancount);

				}
				resultSet.close();
				final String epcHex = message.getKey().getString("DEPT_NBR")+"_"+message.getKey().getString("VND_NBR")+"_"+message.getKey().getString("SKU_UPC_NBR");


				System.out.println(epcHex+"Sku>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+count);

				//c.output(data);
			}
		}));











		rfidScanPipeline
		.apply(GenerateSequence.from(0).withRate(1, Duration.standardSeconds(60L)))
		.apply(
				Window.<Long>into(new GlobalWindows())
				.triggering(Repeatedly.forever(AfterProcessingTime.pastFirstElementInPane()))
				.discardingFiredPanes())
		.apply("TakeGroupCount", ParDo.of(new DoFn<Long, String>() {
			private Spanner spanner = null;
			private DatabaseClient dbClient = null;

			@StartBundle
			public void startBundle(StartBundleContext c){

				final com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions.newBuilder().build();
				spanner = spannerOptions.getService();
				final String spannerProjectID = "mtech-storesys-np";
				final String spannerInstanceID = "cspanner-storesys-np";
				final String spannerDatabaseID = "rfid-db-dev";

				final DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
				dbClient = spanner.getDatabaseClient(db);
			}

			@FinishBundle
			public void finishBundle(FinishBundleContext c){

				dbClient = null;
				spanner.close();

			}
			@ProcessElement
			public void processElement(ProcessContext c) {
				//Row inputRow = c.element();
				final Statement stmntForGroupCount= Statement.newBuilder("select epc.InvScanHdrID, count(1) as groupCount from InvScanEpc epc , invscanhdr hdr where  hdr.invScanhdrId = epc.invscanhdrid and hdr.invscanhdrstatus = 'Scanning'  group by epc.InvScanHdrID")
						.build();
				final ResultSet resultSet = dbClient.singleUseReadOnlyTransaction().executeQuery(stmntForGroupCount);
				while (resultSet.next()) {
					final Struct row = resultSet.getCurrentRowAsStruct();
					LOG.info("Data::"+row.getLong("groupCount")+"::"+row.getLong("InvScanHdrID"));
					final String jsonString = "INV_SCAN_HDR_ID:"+ row.getLong("InvScanHdrID")+",MESSAGE_TYPE:group-count,SCAN_COUNT:"+ row.getLong("groupCount");
					LOG.info("\nWriting to Group Count Pubusb::"+jsonString);
					c.output(jsonString);

				}
				resultSet.close();


			}
		})).apply("WriteCountToPubsub", PubsubIO.writeStrings().to(configProperties.getProperty("group.count.topic.name")));

		rfidScanPipeline
		.apply("ReadNotificationPubsub", PubsubIO.readStrings().fromSubscription(
				"projects/mtech-storesys-np/subscriptions/cycle-count-submit-notification-rfid-np-dev-pull"))
		.apply("JSONToRow", JsonToRow.withSchema(notificationSchema)).apply(ParDo.of(new DoFn<Row, String>() {

			private Spanner spanner = null;
			private DatabaseClient dbClient = null;

			@StartBundle
			public void startBundle(StartBundleContext c) {
				// TransactionFileOptions options =
				// c.getPipelineOptions().as(TransactionFileOptions.class);

				final com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
						.newBuilder().build();
				spanner = spannerOptions.getService();
				final String spannerProjectID = "mtech-storesys-np";
				final String spannerInstanceID = "cspanner-storesys-np";
				final String spannerDatabaseID = "rfid-db-dev";

				final DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
				dbClient = spanner.getDatabaseClient(db);
			}

			@FinishBundle
			public void finishBundle(FinishBundleContext c) {

				dbClient = null;
				spanner.close();

			}

			@ProcessElement
			public void processElement(ProcessContext c) {

				LOG.info("\nData from notification pubsub:::::::::" + c.element().toString());
				final Row inputRow = c.element();
				final String actionRequest = inputRow.getString("actionRequest");
				final long InvScanHdrID = inputRow.getInt64("scanSessionId");
				final String userId = inputRow.getString("userId");

				if (actionRequest.equalsIgnoreCase("done")) {
					long actualCount = 0;
					long totalCount = 0;
					final Statement stmntForActualCount = Statement.newBuilder(
							"select InvScanHdrID,count(*) as actualCount from InvScanEpc where InvScanHdrID = @inscanHeaderId and DeptNbr!=0 and VndNbr!=0  group by InvScanHdrID")
							.bind("inscanHeaderId").to(InvScanHdrID).build();
					final ResultSet resultSet = dbClient.singleUseReadOnlyTransaction()
							.executeQuery(stmntForActualCount);
					if (resultSet.next()) {
						final Struct row = resultSet.getCurrentRowAsStruct();
						actualCount = row.getLong("actualCount");
						LOG.info("Data::" + row.getLong("actualCount") + "::" + row.getLong("InvScanHdrID"));
					}
					resultSet.close();

					final Statement stmntForTotalCount = Statement.newBuilder(
							"select InvScanHdrID,count(*) as totalCount from InvScanEpc where InvScanHdrID = @inscanHeaderId group by InvScanHdrID")
							.bind("inscanHeaderId").to(InvScanHdrID).build();
					final ResultSet resultSetTotalCount = dbClient.singleUseReadOnlyTransaction()
							.executeQuery(stmntForTotalCount);
					if (resultSetTotalCount.next()) {
						final Struct row = resultSetTotalCount.getCurrentRowAsStruct();
						totalCount = row.getLong("totalCount");
						LOG.info("TotalCount::" + row.getLong("totalCount") + "::"
								+ row.getLong("InvScanHdrID"));
					}
					resultSetTotalCount.close();
					final String scanSummary = "INV_SCAN_HDR_ID:" + InvScanHdrID
							+ ",MESSAGE_TYPE:scan-summary,SCAN_COUNT:" + totalCount + ",USER_ID:" + userId
							+ ",EXPECTED_ITEMS_COUNT:" + actualCount;
					LOG.info("Publishing scan summary::" + scanSummary.toString());
					c.output(scanSummary);
				}
			}
		})).apply("WriteScanSummaryToPubsub",
				PubsubIO.writeStrings().to(configProperties.getProperty("group.count.topic.name")));

		rfidScanPipeline.run().waitUntilFinish();
	}
}
