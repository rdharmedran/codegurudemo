package com.macys.cyclecount;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.beam.sdk.io.AvroIO;
import org.apache.beam.sdk.io.FileSystems;
import org.apache.beam.sdk.io.fs.ResourceId;
import org.apache.beam.sdk.options.ValueProvider;
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider;
import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.POutput;
import org.joda.time.Duration;

/**
 * Composite transform to write Avro files to GCS
 * @param <T extends SpecificRecordBase>
 */
public class AvroWriter<T extends SpecificRecordBase> extends PTransform<PCollection<T>, POutput> {
  private String outputPath;
  private Class<T> recordType;
private ValueProvider<String> prefix;

  public AvroWriter<T> withOutputPath(String outputPath) {
    this.outputPath = outputPath;
    return this;
  }
  public AvroWriter<T> withPrefix(ValueProvider<String> prefix) {
	    this.prefix = prefix;
	    return this;
	  }
  public AvroWriter<T> withRecordType(Class<T> recordType) {
    this.recordType = recordType;
    return this;
  }  @Override
  public POutput expand(PCollection<T> inputRecords) {
	  
	  Path baseDir=null;;
	try {
		baseDir = Files.createTempDirectory(Paths.get("C:\\Users\\180484\\Documents\\geoserver\\CCDataflow"), "testwrite");
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  final String baseFilename = baseDir.resolve("prefix").toString();
	  
    // Write to GCS
    return inputRecords
        .apply("Window for 10 seconds", Window.into(FixedWindows.of(Duration.standardSeconds(10))))
        .apply(
            "Write Avro file",
            AvroIO.write(recordType).to(outputPath) .withWindowedWrites()
            .withNumShards(2).withSuffix(".avro"));
  }
}