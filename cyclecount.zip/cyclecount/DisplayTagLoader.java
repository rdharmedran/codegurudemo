package com.macys.cyclecount;

import java.io.IOException;
import java.util.Properties;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.FinishBundle;
import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.DoFn.StartBundle;
import org.apache.beam.sdk.transforms.DoFn.StartBundleContext;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;

public class DisplayTagLoader
 extends DoFn<Long, KV<String, String>> {
	private static final Logger LOG = LoggerFactory.getLogger(DisplayTagLoader.class);
	private static final String DISPLAY_TAG_QUERY = "Select tw.ZlDivnNbr,tw.ZlStorenbr,  tw.EpcHex from tagswritten tw  Where tw.ActiveFlag = 'A' and tw.zldivnnbr = 71 and TW.zlstorenbr = 733  and (tw.ZoneName ) in (Select  zn.ZoneName from RfidZone zn Where zn.ZoneType = 'Audit' and tw.ZlDivnNbr =  zn.ZlDivnNbr and zn.ZlStorenbr = tw.ZlStorenbr)  ";

	private Spanner spanner = null;
	private DatabaseClient dbClient = null;
	Properties configProperties = null;
public DisplayTagLoader() {
	try {
		configProperties = RFIDCycleCountUtil.readPropertiesFile();
	} catch (IOException e) {
		LOG.error("Error reading configuration file::" + e);
	}
}
	@StartBundle
	public void startBundle(StartBundleContext c) {
		com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
				.newBuilder().build();
		spanner = spannerOptions.getService();
		
		String spannerProjectID = configProperties.getProperty("gcp.project.id");
		String spannerInstanceID = configProperties.getProperty("spanner.instance.id");
		String spannerDatabaseID = configProperties.getProperty("spanner.database.id");
		DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
		dbClient = spanner.getDatabaseClient(db);
	}

	@FinishBundle
	public void finishBundle(FinishBundleContext c) {
		try {
			dbClient = null;
			spanner.close();
		} catch (Exception e) {
			LOG.error("error while loading lookup>>>>>>>>>>>>>>>>>>>>>>>>>", e);
		}
	}

	@ProcessElement
	public void processElement(ProcessContext c) {
		Statement stmtTogetDisplayEpc = Statement.newBuilder(DISPLAY_TAG_QUERY).build();
		LOG.info("Display Tag Loading >>>>>>>>>>>>>>>>>>>>>>" + stmtTogetDisplayEpc.toString());
		ResultSet resultSet = dbClient.singleUseReadOnlyTransaction().executeQuery(stmtTogetDisplayEpc);
		while (resultSet.next()) {
			Struct row = resultSet.getCurrentRowAsStruct();
			String epcHex = row.getString(2);
			c.output(KV.of(epcHex, epcHex));
		}
		resultSet.close();
	}

}
