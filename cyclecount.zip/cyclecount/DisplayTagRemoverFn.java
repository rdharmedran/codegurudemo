package com.macys.cyclecount;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.FinishBundle;
import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.DoFn.StartBundle;
import org.apache.beam.sdk.transforms.DoFn.StartBundleContext;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;

public class DisplayTagRemoverFn
 extends DoFn<KV<String, Iterable<Row>>,  KV<String,Row>> {
	private static final Logger LOG = LoggerFactory.getLogger(DisplayTagRemoverFn.class);
	private static final String DISPLAY_TAG_QUERY = "Select tw.ZlDivnNbr,tw.ZlStorenbr,  tw.EpcHex from tagswritten tw  Where tw.ActiveFlag = 'A' and tw.zldivnnbr = 71 and TW.zlstorenbr = 733  and (tw.ZoneName ) in (Select  zn.ZoneName from RfidZone zn Where zn.ZoneType = 'Audit' and tw.ZlDivnNbr =  zn.ZlDivnNbr and zn.ZlStorenbr = tw.ZlStorenbr)  ";

	
	Properties configProperties = null;
	private PCollectionView<Map<String, String>> displayEpcMap;
	
	public DisplayTagRemoverFn() {
		
	}
		
public DisplayTagRemoverFn(PCollectionView<Map<String, String>> displayEpcMap) {
	this.displayEpcMap=displayEpcMap;
}
	

	@ProcessElement
	public void processElement(ProcessContext c) {
		Map<String, String> sideInoput = c.sideInput(displayEpcMap);
		Iterable<Row> inputRow = c.element().getValue();
		Stream<Row> result = StreamSupport.stream(inputRow.spliterator(), false);
		result.filter(entry -> !sideInoput.containsKey(entry.getString("EPC_HEX")))
				.forEach(n -> c.output(KV.of(n.getString("INV_SCAN_HDR_ID"),n)));
	
		
	}


}
