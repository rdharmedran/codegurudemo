package com.macys.cyclecount;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.windowing.IntervalWindow;
import org.apache.beam.sdk.state.MapState;
import org.apache.beam.sdk.state.ReadableState;
import org.apache.beam.sdk.state.StateSpec;
import org.apache.beam.sdk.state.StateSpecs;
import org.apache.beam.sdk.state.TimeDomain;
import org.apache.beam.sdk.state.Timer;
import org.apache.beam.sdk.state.TimerSpec;
import org.apache.beam.sdk.state.TimerSpecs;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.FinishBundle;
import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.DoFn.StartBundle;
import org.apache.beam.sdk.transforms.DoFn.StartBundleContext;
import org.apache.beam.sdk.transforms.DoFn.StateId;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;

public class GroupCountFn extends DoFn<KV<String, Iterable<Row>>, KV<String, Long>> {
	private static final Logger LOG = LoggerFactory.getLogger(GroupCountFn.class);
	private static final String DISPLAY_TAG_QUERY = "Select tw.ZlDivnNbr,tw.ZlStorenbr,  tw.EpcHex from tagswritten tw  Where tw.ActiveFlag = 'A' and tw.zldivnnbr = 71 and TW.zlstorenbr = 733  and (tw.ZoneName ) in (Select  zn.ZoneName from RfidZone zn Where zn.ZoneType = 'Audit' and tw.ZlDivnNbr =  zn.ZlDivnNbr and zn.ZlStorenbr = tw.ZlStorenbr)  ";

	Properties configProperties = null;
	private PCollectionView<Map<String, String>> displayEpcMap;

	public GroupCountFn() {

	}
	 private static final String EXPIRY_STATE_NAME = "expiry";
	 private static final String DATA_HOLDER_NAME = "Value";
	@StateId("Value")
	private final StateSpec<MapState<String, Long>> mapState = StateSpecs.map();
	@TimerId(EXPIRY_STATE_NAME)
    private final TimerSpec expirySpec = TimerSpecs.timer(TimeDomain.PROCESSING_TIME);

 

	@ProcessElement
	public void processElement(ProcessContext context, IntervalWindow window,@StateId("Value") MapState<String, Long> valueState,@TimerId(EXPIRY_STATE_NAME) Timer expiryTimer) {
		try {
			KV<String, Iterable<Row>> element = context.element();
			
			 if (valueState.get(element.getKey()) == null) {
		          // timer will be triggered when the window ends
		          expiryTimer.set(window.maxTimestamp());
		      }

			ReadableState<Long> letterSumState = valueState.get(element.getKey());
			long currentSum = letterSumState.read() != null ? letterSumState.read() : 0;
			final Iterable<Row> inputRow = context.element().getValue();
			final long count = StreamSupport.stream(inputRow.spliterator(), false).count();
			final long key = Long.parseLong(context.element().getKey());

			long letterSum = currentSum + count;
			valueState.put(element.getKey(), letterSum);
			LOG.info(valueState.get(element.getKey()) + "<>=" + valueState.get(element.getKey()).read());
			LOG.info(window.toString()+"<><>"+key + "<>=<>" + count);
			context.output(KV.of(element.getKey(), letterSum));

		} catch (Exception e) {
			LOG.error("Init currentValue with zero", e);
		}
		// LOG.info("message: "+message);
		// LOG.info(message.getKey()+"="+currentValue);

		// valueState.write( KV.of(message.getKey(),currentValue));
	}
	
	 @OnTimer(EXPIRY_STATE_NAME)
	    public void flushOnExpiringState(
	        OnTimerContext context,
	        @StateId(DATA_HOLDER_NAME) MapState<String, Long> valueState) {
	      context.output((KV<String, Long>) valueState.entries().read());
	    }

}
