package com.macys.cyclecount.async;

import com.google.common.collect.Maps;
import com.google.common.collect.Queues;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.FinishBundle;
import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.DoFn.StartBundle;
import org.apache.beam.sdk.transforms.windowing.BoundedWindow;
import org.joda.time.Instant;

import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;

/**
 * A {@link DoFn} that handles asynchronous requests to an external service.
 */
public abstract class BaseAsyncDoFn<InputT, OutputT,  FutureT>
    extends DoFnWithResource<InputT, OutputT> {

  /**
   * Process an element asynchronously.
   */
  public abstract FutureT processElement(InputT input);

  protected abstract void waitForFutures(Iterable<FutureT> futures)
      throws InterruptedException, ExecutionException;
  protected abstract FutureT addCallback(FutureT future,
                                         Function<OutputT, Void> onSuccess,
                                         Function<Throwable, Void> onFailure);

  private final ConcurrentMap<UUID, FutureT> futures = Maps.newConcurrentMap();
  private final ConcurrentLinkedQueue<Result> results = Queues.newConcurrentLinkedQueue();
  private final ConcurrentLinkedQueue<Throwable> errors = Queues.newConcurrentLinkedQueue();

  @StartBundle
  public void startBundle() {
    futures.clear();
    results.clear();
    errors.clear();
  }

  @FinishBundle
  public void finishBundle(FinishBundleContext c) {
    if (!futures.isEmpty()) {
      try {
        waitForFutures(futures.values());
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        throw new RuntimeException("Failed to process futures", e);
      } catch (ExecutionException e) {
        throw new RuntimeException("Failed to process futures", e);
      }
    }
    flush(c);
  }

  @ProcessElement
  public void processElement(ProcessContext c, BoundedWindow window) {
    flush(c);

    final UUID uuid = UUID.randomUUID();
    FutureT future = addCallback(processElement(c.element()), r -> {
      results.add(new Result(r, c.timestamp(), window));
      futures.remove(uuid);
      return null;
    }, t -> {
      errors.add(t);
      futures.remove(uuid);
      return null;
    });
    // This `put` may happen after `remove` in the callbacks but it's OK since either the result
    // or the error would've already been pushed to the corresponding queues and we are not losing
    // data. `waitForFutures` in `finishBundle` blocks until all pending futures, including ones
    // that may have already completed, and `startBundle` clears everything.
    futures.put(uuid, future);
  }

  private void flush(ProcessContext c) {
    if (!errors.isEmpty()) {
      RuntimeException e = new RuntimeException("Failed to process futures");
      Throwable t = errors.poll();
      while (t != null) {
        e.addSuppressed(t);
        t = errors.poll();
      }
      throw e;
    }
    Result r = results.poll();
    while (r != null) {
      c.output(r.output);
      r = results.poll();
    }
  }

  private void flush(FinishBundleContext c) {
    if (!errors.isEmpty()) {
      RuntimeException e = new RuntimeException("Failed to process futures");
      Throwable t = errors.poll();
      while (t != null) {
        e.addSuppressed(t);
        t = errors.poll();
      }
      throw e;
    }
    Result r = results.poll();
    while (r != null) {
      c.output(r.output, r.timestamp, r.window);
      r = results.poll();
    }
  }

  private class Result {
    private OutputT output;
    private Instant timestamp;
    private BoundedWindow window;

    Result(OutputT output, Instant timestamp, BoundedWindow window) {
      this.output = output;
      this.timestamp = timestamp;
      this.window = window;
    }
  }

}
