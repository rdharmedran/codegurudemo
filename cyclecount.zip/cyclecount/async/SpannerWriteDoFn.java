package com.macys.cyclecount.async;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;

import org.apache.beam.vendor.guava.v26_0_jre.com.google.common.util.concurrent.MoreExecutors;

import com.google.cloud.spanner.Mutation;

public class SpannerWriteDoFn extends JavaAsyncDoFn<Mutation, String> {
	public SpannerWriteDoFn() {
		
	}

	@Override
	public CompletableFuture<String> processElement(Mutation mutations) {
		CompletableFuture<String> completableFuture =createResource().request(mutations);
		return completableFuture;
	}

	@Override
	public ResourceType getResourceType() {
		return ResourceType.PER_CLASS;
	}

	@Override
	public JavaClient createResource() {
		// TODO Auto-generated method stub
		return  JavaClient.getClient();
	}
	 
	}