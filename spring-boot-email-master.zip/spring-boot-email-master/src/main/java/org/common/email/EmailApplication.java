package org.common.email;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by abburi on 6/18/17.
 */

@SpringBootApplication
public class EmailApplication {

    public static void main(String[] args){
        SpringApplication.run(EmailApplication.class, args);
    }

}
